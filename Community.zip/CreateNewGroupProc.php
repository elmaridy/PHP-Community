<?php
session_start();
include("db_info.php");
if(isset($_SESSION["UserID"]))
{
    $user=$_SESSION["UserID"];
if(isset($_POST["GroupName"]) && isset($_POST["GroupAbout"]))
{
    $gname = $_POST["GroupName"];
    $gabout = $_POST["GroupAbout"];
    if(!empty($_FILES['GroupImage']['name']))
    {
        $image = $_FILES['GroupImage'];
         $con = mysqli_connect(HOST,UN,PW,DB);
            $sql = "insert into scoop(scoop_name,scoop_type) values('$gname',1)";
            $r = mysqli_query($con,$sql);
            $sql = "SELECT LAST_INSERT_ID();";
            $r = mysqli_query($con,$sql);
            if($p = mysqli_fetch_array($r))
            { $last_id = $p[0];}
            $d = date("Y-M-D-h-m-s");
            $target_dir = "images/Scoop/";
            $imageFileType = pathinfo($image["name"],PATHINFO_EXTENSION);
            $target_file = $target_dir.$last_id.$d.".".$imageFileType;
            $uploadOk = 1;
            // Check if image file is a actual image or fake image
            if(isset($_POST["submit"])) {
                $check = getimagesize($image["tmp_name"]);
                if($check !== false) {
                    echo "File is an image - " . $check["mime"] . ".";
                    $uploadOk = 1;
                } else {
                    echo "File is not an image.";
                    $uploadOk = 0;
                }
            }
            // Check if file already exists
            if (file_exists($target_file)) {
                echo "Sorry, file already exists.";
                $uploadOk = 0;
            }
            // Check file size
            if ($image["size"] > 500000) {
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" ) {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }
            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                echo "Sorry, your file was not uploaded.";
            // if everything is ok, try to upload file
            } else {
                if (!move_uploaded_file($image["tmp_name"], $target_file)) {echo "Sorry, there was an error uploading your file.";}
                else
                {
                    $sql = "INSERT INTO `group` VALUES ($last_id,'$gname','$target_file','$gabout')";
                    $r = mysqli_query($con,$sql);
                    $sql = "INSERT INTO user_group VALUES ($user,$last_id,true)";
                    $r = mysqli_query($con,$sql);
                }
            }
            mysqli_close($con);
            header("Location: GroupShow.php?groupid=$last_id");
        }
        else 
        {
            $image = 'images/Scoop/defaultG.png';
            $con = mysqli_connect(HOST,UN,PW,DB);
            $sql = "insert into scoop (scoop_name,scoop_type) values('$gname',1)";
            $r = mysqli_query($con,$sql);
            $sql = "SELECT LAST_INSERT_ID();";
            $r = mysqli_query($con,$sql);
            if($p = mysqli_fetch_array($r))
            { $last_id = $p[0];}
            $sql = "INSERT INTO `group` VALUES ($last_id,'$gname','$image','$gabout')";
            $r = mysqli_query($con,$sql);
            $sql = "INSERT INTO user_group VALUES ($user,$last_id,true)";
            echo $sql;
            $r = mysqli_query($con,$sql);
            mysqli_close($con);
            header("Location: GroupShow.php?groupid=$last_id");
        }
    }
    else
    {
        header("Location : Library.php");
    }
}
else
{
    header("location: Registeration.php");
}
?>
