<?php
	include("db_info.php");
	$user_id = $_POST['UserID'];
	$post_id = $_POST['PostID'];
	$comm_text = $_POST['CommentText'];
	$con = mysqli_connect(HOST,UN,PW,DB);
	$sql = "INSERT INTO post_comments (post_id , commenter_id , comm_text) values ( $post_id , $user_id , '$comm_text')";
	$rslt = mysqli_query($con , $sql);
    $d=date('Y-m-d H:i:s');
	$sql = 
        "INSERT INTO notification (note_text , note_link , note_img, user_id , note_time) SELECT  concat((select concat(first_name,' ', last_name) from user where user_id = $user_id),' ' ,'commented on your post.' ),'PostShow.php?postid=$post_id',(SELECT profile_image_path from user where user_id = $user_id) ,(SELECT poster_id FROM post where post_id = $post_id) ,'$d' 
        WHERE (SELECT posters.poster_id from post join posters using (poster_id) where post_id = $post_id ) != $user_id and (SELECT posters.poster_type from post join posters using (poster_id) where post_id = $post_id ) = 0" ;
	$rslt = mysqli_query($con , $sql);
    $sql = "SELECT first_name,last_name,profile_image_path FROM user WHERE user_id = $user_id";
    $rslt = mysqli_query($con , $sql);
	mysqli_close($con);
	if ($r = mysqli_fetch_array($rslt))
    {
        echo json_encode($r);
    }
?>