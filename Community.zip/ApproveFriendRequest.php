<?php
	include("db_info.php");
	$user_id = $_POST['UserID'];
	$accesseduser_id = $_POST['AccessedUserID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
    $sql = "CALL AFR ((SELECT request FROM friend_request where sender_id =$accesseduser_id AND reciver_id =$user_id))";
    $rslt = mysqli_query($con , $sql);
    mysqli_close($con);
	if ($rslt == 1)
	{
		die( "done");
	}
	else
	{
		die( "error");
	}
?>