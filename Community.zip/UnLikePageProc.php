<?php
include("db_info.php");
$userid = $_POST["UserID"];
$pageid = $_POST["AccessedPageID"];
$con = mysqli_connect(HOST,UN,PW,DB);
$sql = "DELETE FROM user_pages WHERE user_id =  $userid AND page_id = $pageid ";
$rslt = mysqli_query($con,$sql);
mysqli_close($con);
if ($rslt == 1)
{
	die( "done");
}
else
{
    die( "error");
}
?>