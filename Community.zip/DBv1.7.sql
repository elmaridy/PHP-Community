-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 07, 2017 at 12:58 PM
-- Server version: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `community`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `AFR` (`request_id` INT)  BEGIN
UPDATE friend_request SET is_valid = 0 , is_approved = 1 WHERE request = request_id ;
INSERT INTO user_friends VALUES ((SELECT sender_id FROM friend_request WHERE request = request_id),			(SELECT reciver_id FROM friend_request WHERE request = request_id)),((SELECT reciver_id FROM friend_request WHERE request = request_id),(SELECT sender_id FROM friend_request WHERE request = request_id));
    END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `blog`
--

CREATE TABLE `blog` (
  `blog_id` int(11) NOT NULL,
  `blog_name` varchar(100) NOT NULL,
  `blog_img` varchar(100) NOT NULL,
  `blog_about` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `blog`
--

INSERT INTO `blog` (`blog_id`, `blog_name`, `blog_img`, `blog_about`) VALUES
(10, 'Fashion Blog', 'images/ServerImages/FashionBlog7-2-2017.png', 'For the modern fashion describtions'),
(11, 'Travelling Blog', 'images/ServerImages/TravellingBlog7-2-2017.png', 'For travelling advice and shares'),
(12, 'Tourism Blog', 'images/ServerImages/TourismBlog7-2-2017.jpg', 'For tourism advices and recommendations.'),
(13, 'Health Blog', 'images/ServerImages/HealthBlog7-2-2017.png', 'For Online consulting and replies.'),
(14, 'Shopping Blog', 'images/ServerImages/ShoppingBlog7-2-2017.png', 'For online shopping and recommendations.');

-- --------------------------------------------------------

--
-- Table structure for table `friend_request`
--

CREATE TABLE `friend_request` (
  `request` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `reciver_id` int(11) NOT NULL,
  `is_valid` bit(1) NOT NULL,
  `is_approved` bit(1) NOT NULL,
  `seen` bit(1) NOT NULL DEFAULT b'0',
  `friend_request_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `friend_request`
--

INSERT INTO `friend_request` (`request`, `sender_id`, `reciver_id`, `is_valid`, `is_approved`, `seen`, `friend_request_time`) VALUES
(2, 1, 4, b'0', b'1', b'1', '2017-01-28 12:00:00'),
(3, 1, 4, b'0', b'1', b'1', '2017-02-01 12:02:25'),
(4, 4, 2, b'0', b'1', b'1', '2017-02-01 12:04:14'),
(5, 2, 4, b'0', b'1', b'1', '2017-02-01 12:27:28'),
(6, 4, 1, b'1', b'0', b'1', '2017-02-02 00:37:24'),
(7, 8, 1, b'1', b'0', b'0', '2017-02-04 18:04:28'),
(8, 9, 8, b'0', b'1', b'1', '2017-02-04 21:17:07'),
(9, 10, 8, b'0', b'1', b'1', '2017-02-07 19:22:45'),
(10, 28, 9, b'0', b'1', b'1', '2017-02-09 20:46:48'),
(11, 8, 2, b'1', b'0', b'0', '2017-02-22 12:17:00');

-- --------------------------------------------------------

--
-- Table structure for table `group`
--

CREATE TABLE `group` (
  `group_id` int(11) NOT NULL,
  `group_name` varchar(25) NOT NULL,
  `group_image_path` varchar(50) NOT NULL,
  `group_about` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `group`
--

INSERT INTO `group` (`group_id`, `group_name`, `group_image_path`, `group_about`) VALUES
(3, 'Zahran School Boys', 'images/scoop/defaultG.png', 'For Zahran students'),
(8, 'Barca Fans', 'images/Scoop/defaultG.png', 'For All Barcelonista'),
(9, 'Premier League', 'images/Scoop/92017-Feb-Tue-11-02-26.jpg', 'A Full recovery for premier league matches');

-- --------------------------------------------------------

--
-- Table structure for table `joining_request`
--

CREATE TABLE `joining_request` (
  `request_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `seen` bit(1) NOT NULL DEFAULT b'0',
  `is_valid` bit(1) NOT NULL,
  `is_approved` int(1) NOT NULL,
  `joining_request_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `joining_request`
--

INSERT INTO `joining_request` (`request_id`, `sender_id`, `group_id`, `seen`, `is_valid`, `is_approved`, `joining_request_time`) VALUES
(2, 10, 9, b'1', b'0', 1, '2017-02-07 18:49:44'),
(3, 9, 9, b'1', b'0', 1, '2017-02-07 19:19:37'),
(4, 10, 9, b'1', b'0', 0, '2017-02-07 19:22:55'),
(5, 9, 9, b'1', b'0', 1, '2017-02-07 19:30:44'),
(6, 10, 9, b'1', b'0', 1, '2017-02-07 19:31:08');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `note_id` int(10) NOT NULL,
  `note_text` longtext NOT NULL,
  `note_link` varchar(100) NOT NULL,
  `note_img` varchar(50) NOT NULL,
  `user_id` int(10) NOT NULL,
  `ISRead` bit(1) NOT NULL DEFAULT b'0',
  `note_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`note_id`, `note_text`, `note_link`, `note_img`, `user_id`, `ISRead`, `note_time`) VALUES
(14, 'Mohamed Alaa liked your post.', 'PostShow.php?postid=4', 'images/posters/1.jpg', 4, b'1', '2016-12-23 12:21:04'),
(15, 'Osama Gamal liked your post.', 'PostShow.php?postid=10', 'images/posters/4.jpg', 1, b'1', '2016-12-23 12:30:52'),
(16, 'Osama Gamal liked your post.', 'PostShow.php?postid=11', 'images/posters/4.jpg', 1, b'1', '2016-12-23 12:30:53'),
(17, 'Osama Gamal commented on your post.', 'PostShow.php?postid=11', 'images/posters/4.jpg', 1, b'1', '2016-12-23 12:31:19'),
(18, 'Kamel Ahmed liked your post.', 'PostShow.php?postid=11', 'images/posters/2.jpg', 1, b'1', '2016-12-23 12:31:48'),
(19, 'Kamel Ahmed liked your post.', 'PostShow.php?postid=9', 'images/posters/2.jpg', 1, b'1', '2016-12-23 12:48:13'),
(20, 'Osama Gamal liked your post.', 'PostShow.php?postid=9', 'images/posters/4.jpg', 1, b'1', '2017-01-27 20:50:08'),
(21, 'Mohamed Alaa liked your post.', 'PostShow.php?postid=13', 'images/posters/1.jpg', 2, b'1', '2017-01-29 13:10:55'),
(22, 'Hossam Gamal commented on your post.', 'PostShow.php?postid=15', 'images/posters/82017-Feb-Sat-04-02-13.jpg', 1, b'0', '2017-02-04 17:17:32'),
(23, 'Hossam Gamal commented on your post.', 'PostShow.php?postid=10', 'images/posters/82017-Feb-Sat-04-02-13.jpg', 1, b'0', '2017-02-04 17:19:34'),
(24, 'Hossam Gamal commented on your post.', 'PostShow.php?postid=11', 'images/posters/82017-Feb-Sat-04-02-13.jpg', 1, b'0', '2017-02-04 17:21:16'),
(25, 'Hossam Gamal commented on your post.', 'PostShow.php?postid=1', 'images/posters/82017-Feb-Sat-04-02-13.jpg', 1, b'0', '2017-02-04 17:57:10'),
(26, 'Hossam Gamal commented on your post.', 'PostShow.php?postid=1', 'images/posters/82017-Feb-Sat-04-02-13.jpg', 1, b'0', '2017-02-04 17:58:06'),
(27, 'Hossam Gamal commented on your post.', 'PostShow.php?postid=1', 'images/posters/82017-Feb-Sat-04-02-13.jpg', 1, b'0', '2017-02-04 17:59:16'),
(28, 'Hossam Gamal commented on your post.', 'PostShow.php?postid=1', 'images/posters/82017-Feb-Sat-04-02-13.jpg', 1, b'0', '2017-02-04 18:00:01'),
(29, 'Hossam Gamal commented on your post.', 'PostShow.php?postid=1', 'images/posters/82017-Feb-Sat-04-02-13.jpg', 1, b'0', '2017-02-04 18:01:33'),
(30, 'Hossam Gamal commented on your post.', 'PostShow.php?postid=1', 'images/posters/82017-Feb-Sat-04-02-13.jpg', 1, b'0', '2017-02-04 18:10:54'),
(31, 'Hossam Gamal commented on your post.', 'PostShow.php?postid=1', 'images/posters/82017-Feb-Sat-04-02-13.jpg', 1, b'0', '2017-02-04 18:59:28'),
(32, 'Hossam Gamal commented on your post.', 'PostShow.php?postid=1', 'images/posters/82017-Feb-Sat-04-02-13.jpg', 1, b'0', '2017-02-04 19:02:46'),
(33, 'Hossam Gamal commented on your post.', 'PostShow.php?postid=1', 'images/posters/82017-Feb-Sat-04-02-13.jpg', 1, b'0', '2017-02-04 19:09:52'),
(34, 'Hossam Gamal commented on your post.', 'PostShow.php?postid=1', 'images/posters/82017-Feb-Sat-04-02-13.jpg', 1, b'0', '2017-02-04 19:12:15'),
(35, 'Hossam Gamal commented on your post.', 'PostShow.php?postid=1', 'images/posters/82017-Feb-Sat-04-02-13.jpg', 1, b'0', '2017-02-04 19:13:04'),
(36, 'Hossam Gamal commented on your post.', 'PostShow.php?postid=1', 'images/posters/82017-Feb-Sat-04-02-13.jpg', 1, b'0', '2017-02-04 19:13:58'),
(37, 'Hossam Gamal commented on your post.', 'PostShow.php?postid=1', 'images/posters/82017-Feb-Sat-04-02-13.jpg', 1, b'0', '2017-02-04 19:14:44'),
(38, 'Sara Ahmed liked your post.', 'PostShow.php?postid=45', 'images/posters/92017-Feb-Fri-09-02-48.jpg', 8, b'1', '2017-02-04 19:19:47'),
(42, 'You had been added to Barcelona admins.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 9, b'1', '2017-02-07 00:13:35'),
(44, 'You had been added to Barcelona admins.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 10, b'1', '2017-02-07 00:16:10'),
(45, 'You had been added to Barcelona admins.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 1, b'0', '2017-02-07 00:17:42'),
(46, 'You had been removed from Barcelona adminstration.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 1, b'0', '2017-02-07 00:22:49'),
(47, 'You had been removed from Barcelona adminstration.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 4, b'0', '2017-02-07 00:24:50'),
(48, 'You had been removed from Barcelona adminstration.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 9, b'1', '2017-02-07 00:26:17'),
(49, 'You had been removed from Barcelona adminstration.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 2, b'0', '2017-02-07 00:27:13'),
(50, 'You had been removed from Barcelona adminstration.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 10, b'1', '2017-02-07 00:30:06'),
(51, 'You had been added to Barcelona admins.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 1, b'0', '2017-02-07 00:31:09'),
(52, 'You had been added to Barcelona admins.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 2, b'0', '2017-02-07 00:31:12'),
(53, 'You had been added to Barcelona admins.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 4, b'0', '2017-02-07 00:31:14'),
(54, 'You had been removed from Barcelona adminstration.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 1, b'0', '2017-02-07 00:31:18'),
(55, 'You had been removed from Barcelona adminstration.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 4, b'0', '2017-02-07 00:31:47'),
(56, 'You had been removed from Barcelona adminstration.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 2, b'0', '2017-02-07 00:35:17'),
(57, 'You had been added to Barcelona admins.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 1, b'0', '2017-02-07 00:35:54'),
(58, 'You had been removed from Barcelona adminstration.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 1, b'0', '2017-02-07 00:35:57'),
(59, 'You had been added to Barcelona admins.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 1, b'0', '2017-02-07 00:38:06'),
(60, 'You had been removed from Barcelona adminstration.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 1, b'0', '2017-02-07 00:38:08'),
(61, 'You had been added to Barcelona admins.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 9, b'1', '2017-02-07 00:38:35'),
(62, 'You had been removed from Barcelona adminstration.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 9, b'1', '2017-02-07 00:38:37'),
(63, 'You had been added to Barcelona admins.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 9, b'1', '2017-02-07 00:38:43'),
(64, 'You had been added to Barcelona admins.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 8, b'1', '2017-02-07 00:38:44'),
(65, 'You had been added to Barcelona admins.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 4, b'0', '2017-02-07 00:38:45'),
(66, 'You had been added to Barcelona admins.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 8, b'1', '2017-02-07 00:38:46'),
(67, 'You had been removed from Barcelona adminstration.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 8, b'1', '2017-02-07 00:38:49'),
(68, 'You had been removed from Barcelona adminstration.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 8, b'1', '2017-02-07 00:38:58'),
(69, 'You had been added to Barcelona admins.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 10, b'1', '2017-02-07 00:54:49'),
(70, 'You had been removed from Barcelona adminstration.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 10, b'1', '2017-02-07 00:54:53'),
(71, 'You had been removed from Barcelona adminstration.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 9, b'1', '2017-02-07 00:54:54'),
(72, 'You had been removed from Barcelona adminstration.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 4, b'0', '2017-02-07 00:54:56'),
(73, 'You had been removed from Barcelona adminstration.', 'PageShow.php?accessedpage=27', 'images/posters/272017-Feb-Sun-03-02-07.jpg', 2, b'0', '2017-02-07 00:54:58'),
(74, 'You had been added to Premier League group admins.', 'GroupShow.php?groupid=9', 'images/Scoop/92017-Feb-Tue-11-02-26.jpg', 1, b'0', '2017-02-07 16:30:53'),
(75, 'You had been added to Premier League group admins.', 'GroupShow.php?groupid=9', 'images/Scoop/92017-Feb-Tue-11-02-26.jpg', 4, b'0', '2017-02-07 16:31:42'),
(76, 'You had been added to Premier League group admins.', 'GroupShow.php?groupid=9', 'images/Scoop/92017-Feb-Tue-11-02-26.jpg', 9, b'1', '2017-02-07 16:33:58'),
(77, 'You had been removed from Premier League group adminstration.', 'GroupShow.php?groupid=9', 'images/Scoop/92017-Feb-Tue-11-02-26.jpg', 1, b'0', '2017-02-07 16:34:07'),
(78, 'You had been removed from Premier League group adminstration.', 'GroupShow.php?groupid=9', 'images/Scoop/92017-Feb-Tue-11-02-26.jpg', 4, b'0', '2017-02-07 16:34:35'),
(79, 'You had been removed from Premier League group members.', 'GroupShow.php?groupid=9', 'images/Scoop/92017-Feb-Tue-11-02-26.jpg', 1, b'0', '2017-02-07 18:10:57'),
(80, 'You had been added to Premier League group members.', 'GroupShow.php?groupid=9', 'images/Scoop/92017-Feb-Tue-11-02-26.jpg', 1, b'0', '2017-02-07 18:11:09'),
(81, 'You had been added to Premier League group members.', 'GroupShow.php?groupid=(SELECT group_id FROM joining_request WHERE request_id = 2)', 'images/Scoop/92017-Feb-Tue-11-02-26.jpg', 10, b'1', '2017-02-07 19:13:59'),
(82, 'You had been removed from Premier League group members.', 'GroupShow.php?groupid=9', 'images/Scoop/92017-Feb-Tue-11-02-26.jpg', 9, b'1', '2017-02-07 19:19:04'),
(83, 'You had been removed from Premier League group members.', 'GroupShow.php?groupid=9', 'images/Scoop/92017-Feb-Tue-11-02-26.jpg', 10, b'1', '2017-02-07 19:19:05'),
(84, 'You had been added to Premier League group members.', 'GroupShow.php?groupid=(SELECT group_id FROM joining_request WHERE request_id = 3)', 'images/Scoop/92017-Feb-Tue-11-02-26.jpg', 9, b'1', '2017-02-07 19:23:36'),
(85, 'You had been added to Premier League group members.', 'GroupShow.php?groupid=(SELECT group_id FROM joining_request WHERE request_id = 6)', 'images/Scoop/92017-Feb-Tue-11-02-26.jpg', 10, b'0', '2017-02-07 19:33:35'),
(86, 'You had been added to Premier League group members.', 'GroupShow.php?groupid=(SELECT group_id FROM joining_request WHERE request_id = 5)', 'images/Scoop/92017-Feb-Tue-11-02-26.jpg', 9, b'1', '2017-02-07 19:35:01'),
(87, 'You had been removed from Premier League group members.', 'GroupShow.php?groupid=9', 'images/Scoop/92017-Feb-Tue-11-02-26.jpg', 1, b'0', '2017-02-07 19:35:17'),
(88, 'You had been removed from Premier League group members.', 'GroupShow.php?groupid=9', 'images/Scoop/92017-Feb-Tue-11-02-26.jpg', 4, b'0', '2017-02-07 19:35:18');

-- --------------------------------------------------------

--
-- Table structure for table `page`
--

CREATE TABLE `page` (
  `page_id` int(11) NOT NULL,
  `page_name` varchar(25) NOT NULL,
  `page_about` varchar(200) DEFAULT NULL,
  `page_type_id` int(2) NOT NULL,
  `page_image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `page`
--

INSERT INTO `page` (`page_id`, `page_name`, `page_about`, `page_type_id`, `page_image`) VALUES
(3, 'Sarcasm Page', 'This Is Our Sarcasm Page', 1, 'images/posters/3.jpg'),
(27, 'Barcelona', 'We Are Barca Fans . A full covering for barca news', 1, 'images/posters/272017-Feb-Sun-03-02-07.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `page_admins`
--

CREATE TABLE `page_admins` (
  `page_id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `page_admins`
--

INSERT INTO `page_admins` (`page_id`, `admin_id`) VALUES
(3, 1),
(27, 1),
(27, 8);

-- --------------------------------------------------------

--
-- Table structure for table `page_type`
--

CREATE TABLE `page_type` (
  `page_type_id` int(2) NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `page_type`
--

INSERT INTO `page_type` (`page_type_id`, `type`) VALUES
(1, 'Community');

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `post_id` int(10) NOT NULL,
  `poster_id` int(10) NOT NULL,
  `scoop_id` int(10) NOT NULL,
  `post_image` varchar(100) DEFAULT NULL,
  `post_text` longtext NOT NULL,
  `post_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`post_id`, `poster_id`, `scoop_id`, `post_image`, `post_text`, `post_time`) VALUES
(1, 1, 1, 'images/posts/1.jpg', 'I Love The Tree This Is A beautiful Tree Here !!', '2016-12-02 01:23:29'),
(2, 2, 1, 'images/posts/2.jpg', 'I Love Egypt And The Pyramids :-)', '2016-12-02 01:24:42'),
(3, 3, 1, 'images/posts/3.jpg', ' hhhhhhhhhhh that funny moment', '2016-12-02 01:25:43'),
(4, 4, 1, 'images/posts/4.jpg', 'France , Eiffel tower !! ', '2016-12-02 01:26:28'),
(8, 1, 1, 'images/posts/8.jpg', 'Golden Gate Bridge Omg !!', '2016-12-02 00:49:48'),
(9, 1, 1, 'images/posts/9.jpg', 'Awsome Plane !!', '2016-12-02 01:08:03'),
(10, 1, 1, NULL, 'Hello EveryBody Good Day For All Of You !!', '2016-12-03 00:54:56'),
(11, 1, 1, NULL, 'Good Morning Guys !!', '2016-12-02 23:05:05'),
(12, 2, 1, 'images/posts/12.jpg', 'Ibn ElRomy !!', '2016-12-06 16:11:48'),
(13, 2, 1, 'images/posts/13.jpg', 'A great work Messi !!', '2017-01-27 19:57:00'),
(15, 1, 1, 'images/posts/15.jpg', 'Egyyyyyyyyyyyyyyyypt !!\r\nBravo000oo0 Salah !!', '2017-01-27 20:04:15'),
(16, 4, 1, 'images/posts/16.jpg', 'Egyyyyypt!!!!!!!!\r\n\r\n\r\nSALAH :-) !!', '2017-01-27 20:09:46'),
(17, 4, 1, 'images/posts/17.jpg', 'hhhhhhhhhhhhh \r\nAny Time Ghana :-)', '2017-01-27 20:21:49'),
(31, 1, 1, 'images/posts/31.jpg', 'Has Changed Profile Picture', '2017-02-03 12:14:05'),
(43, 2, 1, 'images/posts/43.jpg', 'Has Changed Profile Picture', '2017-02-03 22:37:49'),
(44, 9, 1, 'images/posts/44.jpg', 'Has Changed Profile Picture', '2017-02-03 23:55:49'),
(45, 8, 1, 'images/posts/45.jpg', 'Has Changed Profile Picture', '2017-02-04 18:04:13'),
(46, 8, 2, 'images/posts/46.jpg', 'I Love This Moviiiiiiiiiie !!!', '2017-02-04 19:09:04'),
(47, 8, 1, NULL, 'Hello Everybody Have A good day ......', '2017-02-04 17:10:02'),
(48, 27, 1, 'images/posts/48.jpg', 'Has Changed Profile Picture', '2017-02-05 17:37:31'),
(49, 27, 1, 'images/posts/49.jpg', 'Has Changed Profile Picture', '2017-02-05 17:55:07'),
(52, 27, 1, 'images/posts/52.jpg', 'Leoooooooooooo !!', '2017-02-05 18:02:07'),
(53, 8, 2, 'images/posts/53.jpg', 'El Hadryyyyyyyyyyyyyyyyyyy !!', '2017-02-05 18:05:25'),
(54, 8, 3, NULL, 'Hello Friends', '2017-02-07 13:45:05'),
(55, 8, 10, 'images/posts/55.jpg', 'A very beautiful suit !!', '2017-02-07 21:20:49'),
(56, 8, 10, NULL, 'Any one have a suggestion for a good suit ??', '2017-02-07 21:21:37'),
(57, 28, 1, 'images/posts/57.jpg', 'Has Changed Profile Picture', '2017-02-09 20:46:22');

-- --------------------------------------------------------

--
-- Table structure for table `posters`
--

CREATE TABLE `posters` (
  `poster_id` int(11) NOT NULL,
  `poster_name` varchar(25) NOT NULL,
  `poster_type` int(1) NOT NULL,
  `poster_image` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `posters`
--

INSERT INTO `posters` (`poster_id`, `poster_name`, `poster_type`, `poster_image`) VALUES
(1, 'Mohamed Alaa', 0, 'images/posters/1.jpg'),
(2, 'Kamel Ahmed', 0, 'images/posters/22017-Feb-Fri-08-02-49.jpg'),
(3, 'Sarcasm Page', 1, 'images/posters/3.jpg'),
(4, 'Osama Gamal', 0, 'images/posters/4.jpg'),
(8, 'Hossam Gamal', 0, 'images/posters/82017-Feb-Sat-04-02-13.jpg'),
(9, 'Sara Ahmed', 0, 'images/posters/92017-Feb-Fri-09-02-48.jpg'),
(10, 'Dina Essam', 0, 'images/posters/defaultF.jpg'),
(27, 'Barcelona', 1, 'images/posters/272017-Feb-Sun-03-02-07.jpg'),
(28, 'Aya Saleh', 0, 'images/posters/282017-Feb-Thu-06-02-21.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `post_comments`
--

CREATE TABLE `post_comments` (
  `post_comm_id` int(10) NOT NULL,
  `post_id` int(10) NOT NULL,
  `commenter_id` int(1) NOT NULL,
  `comm_text` varchar(100) NOT NULL,
  `comm_img` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `post_comments`
--

INSERT INTO `post_comments` (`post_comm_id`, `post_id`, `commenter_id`, `comm_text`, `comm_img`) VALUES
(1, 12, 1, 'I Really Love This Guy !!', NULL),
(2, 3, 1, 'hhhh', NULL),
(4, 4, 1, 'Very Great !!', 'images/CommentsImages/4.jpg'),
(5, 2, 1, '', 'images/CommentsImages/5.png'),
(9, 11, 2, 'Good Morning Mohamed !!', NULL),
(10, 1, 2, 'Wow !!', NULL),
(11, 8, 1, 'hhhhh I have visited it since 2010', NULL),
(12, 11, 4, 'Good Morning Dear !!', NULL),
(13, 12, 1, '', 'images/CommentsImages/13.'),
(14, 15, 8, 'Longlife Egypt !!', NULL),
(15, 10, 8, 'For You Too !!', NULL),
(16, 11, 8, 'Good Morning !!', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `post_likes`
--

CREATE TABLE `post_likes` (
  `post_like_id` int(10) NOT NULL,
  `post_id` int(10) NOT NULL,
  `liker_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `post_likes`
--

INSERT INTO `post_likes` (`post_like_id`, `post_id`, `liker_id`) VALUES
(102, 11, 1),
(103, 3, 1),
(104, 10, 2),
(107, 1, 2),
(109, 12, 2),
(110, 1, 1),
(111, 9, 1),
(112, 8, 1),
(115, 8, 2),
(116, 4, 1),
(117, 10, 4),
(118, 11, 4),
(119, 11, 2),
(120, 9, 2),
(121, 10, 1),
(122, 9, 4),
(123, 13, 1),
(124, 45, 9),
(125, 56, 8);

-- --------------------------------------------------------

--
-- Table structure for table `scoop`
--

CREATE TABLE `scoop` (
  `scoop_id` int(11) NOT NULL,
  `scoop_name` varchar(25) NOT NULL,
  `scoop_type` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `scoop`
--

INSERT INTO `scoop` (`scoop_id`, `scoop_name`, `scoop_type`) VALUES
(1, 'Public', 0),
(2, 'Friends', 0),
(3, 'Zahran School Boys', 1),
(8, 'Barca Fans', 1),
(9, 'Premier League', 1),
(10, 'Fashion Blog', 2),
(11, 'Travelling Blog', 2),
(12, 'Tourism Blog', 2),
(13, 'Health Blog', 2),
(14, 'Shopping Blog', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `first_name` varchar(12) NOT NULL,
  `last_name` varchar(12) DEFAULT NULL,
  `email` varchar(25) NOT NULL,
  `password` char(32) NOT NULL,
  `profile_image_path` varchar(50) NOT NULL,
  `IsActive` bit(1) NOT NULL,
  `gender` char(1) NOT NULL,
  `date_of_birth` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `first_name`, `last_name`, `email`, `password`, `profile_image_path`, `IsActive`, `gender`, `date_of_birth`) VALUES
(1, 'Mohamed', 'Alaa', 'mohamedalaa@domain.com', '202cb962ac59075b964b07152d234b70', 'images/posters/1.jpg', b'1', 'M', '1986-07-02'),
(2, 'Kamel', 'Ahmed', 'kamel@gmail.com', '202cb962ac59075b964b07152d234b70', 'images/posters/22017-Feb-Fri-08-02-49.jpg', b'1', 'M', '2000-08-02'),
(4, 'Osama', 'Gamal', 'osos@hotmail.com', '202cb962ac59075b964b07152d234b70', 'images/posters/4.jpg', b'1', 'M', '1996-12-11'),
(8, 'Hossam', 'Gamal', 'elhos@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'images/posters/82017-Feb-Sat-04-02-13.jpg', b'1', 'M', '1989-02-07'),
(9, 'Sara', 'Ahmed', 'sssara@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'images/posters/92017-Feb-Fri-09-02-48.jpg', b'1', 'F', '1994-02-06'),
(10, 'Dina', 'Essam', 'dodoe@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 'images/posters/282017-Feb-Thu-06-02-21.jpg', b'1', 'F', '1999-01-01'),
(28, 'Aya', 'Saleh', 'aya199899@yahoo.com', 'dacd7c3df8c54651c059b19a6d5a5218', 'images/posters/282017-Feb-Thu-06-02-21.jpg', b'1', 'F', '2017-02-12');

-- --------------------------------------------------------

--
-- Table structure for table `user_friends`
--

CREATE TABLE `user_friends` (
  `user_id` int(10) NOT NULL,
  `friend_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_friends`
--

INSERT INTO `user_friends` (`user_id`, `friend_id`) VALUES
(1, 2),
(2, 1),
(2, 4),
(4, 2),
(8, 9),
(8, 10),
(9, 8),
(9, 28),
(10, 8),
(28, 9);

-- --------------------------------------------------------

--
-- Table structure for table `user_group`
--

CREATE TABLE `user_group` (
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `IsAdmin` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_group`
--

INSERT INTO `user_group` (`user_id`, `group_id`, `IsAdmin`) VALUES
(1, 3, b'1'),
(8, 3, b'0'),
(8, 8, b'1'),
(8, 9, b'1'),
(9, 9, b'0'),
(10, 9, b'0');

-- --------------------------------------------------------

--
-- Table structure for table `user_pages`
--

CREATE TABLE `user_pages` (
  `user_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_pages`
--

INSERT INTO `user_pages` (`user_id`, `page_id`) VALUES
(1, 3),
(8, 3);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `blog`
--
ALTER TABLE `blog`
  ADD PRIMARY KEY (`blog_id`);

--
-- Indexes for table `friend_request`
--
ALTER TABLE `friend_request`
  ADD PRIMARY KEY (`request`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `reciver_id` (`reciver_id`);

--
-- Indexes for table `group`
--
ALTER TABLE `group`
  ADD PRIMARY KEY (`group_id`);

--
-- Indexes for table `joining_request`
--
ALTER TABLE `joining_request`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `sender_id` (`sender_id`),
  ADD KEY `group_id` (`group_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`note_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `page`
--
ALTER TABLE `page`
  ADD PRIMARY KEY (`page_id`),
  ADD KEY `page_type_id` (`page_type_id`),
  ADD KEY `page_image` (`page_image`);

--
-- Indexes for table `page_admins`
--
ALTER TABLE `page_admins`
  ADD PRIMARY KEY (`page_id`,`admin_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `page_type`
--
ALTER TABLE `page_type`
  ADD PRIMARY KEY (`page_type_id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`post_id`),
  ADD KEY `poster_id` (`poster_id`),
  ADD KEY `scoop_id` (`scoop_id`);

--
-- Indexes for table `posters`
--
ALTER TABLE `posters`
  ADD PRIMARY KEY (`poster_id`),
  ADD KEY `poster_image` (`poster_image`),
  ADD KEY `poster_image_2` (`poster_image`);

--
-- Indexes for table `post_comments`
--
ALTER TABLE `post_comments`
  ADD PRIMARY KEY (`post_comm_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `commenter_id` (`commenter_id`);

--
-- Indexes for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD PRIMARY KEY (`post_like_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `liker_id` (`liker_id`);

--
-- Indexes for table `scoop`
--
ALTER TABLE `scoop`
  ADD PRIMARY KEY (`scoop_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `profile_image_path` (`profile_image_path`);

--
-- Indexes for table `user_friends`
--
ALTER TABLE `user_friends`
  ADD PRIMARY KEY (`friend_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user_group`
--
ALTER TABLE `user_group`
  ADD PRIMARY KEY (`group_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user_pages`
--
ALTER TABLE `user_pages`
  ADD PRIMARY KEY (`page_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `blog`
--
ALTER TABLE `blog`
  MODIFY `blog_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `friend_request`
--
ALTER TABLE `friend_request`
  MODIFY `request` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `joining_request`
--
ALTER TABLE `joining_request`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `note_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;
--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `post_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
--
-- AUTO_INCREMENT for table `posters`
--
ALTER TABLE `posters`
  MODIFY `poster_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `post_comments`
--
ALTER TABLE `post_comments`
  MODIFY `post_comm_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `post_likes`
--
ALTER TABLE `post_likes`
  MODIFY `post_like_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;
--
-- AUTO_INCREMENT for table `scoop`
--
ALTER TABLE `scoop`
  MODIFY `scoop_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `blog`
--
ALTER TABLE `blog`
  ADD CONSTRAINT `blog_ibfk_1` FOREIGN KEY (`blog_id`) REFERENCES `scoop` (`scoop_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `friend_request`
--
ALTER TABLE `friend_request`
  ADD CONSTRAINT `friend_request_ibfk_1` FOREIGN KEY (`sender_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `friend_request_ibfk_2` FOREIGN KEY (`reciver_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `group`
--
ALTER TABLE `group`
  ADD CONSTRAINT `group_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `scoop` (`scoop_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `joining_request`
--
ALTER TABLE `joining_request`
  ADD CONSTRAINT `joining_request_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `group` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `joining_request_ibfk_2` FOREIGN KEY (`sender_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notification`
--
ALTER TABLE `notification`
  ADD CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `page`
--
ALTER TABLE `page`
  ADD CONSTRAINT `page_ibfk_1` FOREIGN KEY (`page_id`) REFERENCES `posters` (`poster_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `page_ibfk_2` FOREIGN KEY (`page_type_id`) REFERENCES `page_type` (`page_type_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `page_admins`
--
ALTER TABLE `page_admins`
  ADD CONSTRAINT `page_admins_ibfk_1` FOREIGN KEY (`page_id`) REFERENCES `page` (`page_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `page_admins_ibfk_2` FOREIGN KEY (`admin_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `post_ibfk_1` FOREIGN KEY (`scoop_id`) REFERENCES `scoop` (`scoop_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `post_ibfk_2` FOREIGN KEY (`poster_id`) REFERENCES `posters` (`poster_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `post_comments`
--
ALTER TABLE `post_comments`
  ADD CONSTRAINT `post_comments_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `post_comments_ibfk_2` FOREIGN KEY (`commenter_id`) REFERENCES `posters` (`poster_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `post_likes`
--
ALTER TABLE `post_likes`
  ADD CONSTRAINT `post_likes_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `post` (`post_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `post_likes_ibfk_2` FOREIGN KEY (`liker_id`) REFERENCES `posters` (`poster_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `posters` (`poster_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_friends`
--
ALTER TABLE `user_friends`
  ADD CONSTRAINT `user_friends_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_friends_ibfk_2` FOREIGN KEY (`friend_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_group`
--
ALTER TABLE `user_group`
  ADD CONSTRAINT `user_group_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_group_ibfk_2` FOREIGN KEY (`group_id`) REFERENCES `group` (`group_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_pages`
--
ALTER TABLE `user_pages`
  ADD CONSTRAINT `user_pages_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user_pages_ibfk_2` FOREIGN KEY (`page_id`) REFERENCES `page` (`page_id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
