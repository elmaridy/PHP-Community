<?php
	include("db_info.php");
	$user_id = $_GET['UserID'];
    $group_id = $_GET['GroupID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
    $sql = "UPDATE joining_request SET seen = 1 WHERE group_id = $group_id";
    $rslt = mysqli_query($con , $sql);
    $sql = "SELECT request_id,first_name,last_name,profile_image_path FROM joining_request JOIN user on (sender_id = user_id) WHERE group_id = $group_id And is_valid = 1 order by joining_request_time desc";
    $rslt = mysqli_query($con , $sql);
	$CommArray = array();
	while($row = mysqli_fetch_array($rslt)) 
	{
            $CommArray[] = $row;
    }
	mysqli_close($con);
	echo json_encode($CommArray);
?>