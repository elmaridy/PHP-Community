<?php
session_start();
if(isset($_SESSION["UserID"]))
{
if(isset($_GET['accesseduser']))
{
    $accesseduser = $_GET['accesseduser'];
    $user = $_SESSION["UserID"];
    include("db_info.php");
}
else
{
    header ("location : Library.php");
}
function GetUserWallPosts($userid,$accesseduserid)
{
    $con = mysqli_connect(HOST,UN,PW,DB);
	$sql = "select * from user where user_id = $accesseduserid";
	$accesseduser = mysqli_query($con,$sql);
	if ($r = mysqli_fetch_array($accesseduser))
	{
		echo
		"<center>
			<img src = '$r[5]' width='150px' height='150px' alt='userimage' />
			<h1>$r[1] $r[2]</h1>
		</center>
		";
	}
    if($accesseduserid != $userid)
    {
            $sql = "SELECT EXISTS( SELECT * FROM user_friends WHERE user_id = $userid AND friend_id = $accesseduserid)";
            $IsFriendResult = mysqli_query($con,$sql);
            if ($r = mysqli_fetch_array($IsFriendResult))
            {
                if ($r[0] == 1)
                {
                    echo
                    "<center>
                    <input type = 'button' value = 'Unfriend' class = 'btn btn-md UF' id='unfriend' style= 'background-color:#5b92e3;color:white' data-userid = '$userid' data-accesseduserid = '$accesseduserid' />
                    </center>
                    ";
                    $IsFriend = 1;
                }
                else
                {
                    $sql = "SELECT EXISTS( SELECT * FROM friend_request WHERE sender_id = $userid AND reciver_id = $accesseduserid AND Is_valid = 1)";
                    $PendingFRResult = mysqli_query($con,$sql);
                    if ($r = mysqli_fetch_array($PendingFRResult))
                    {
                        if ($r[0] == 1)
                        {
                            echo
                            "<center>
                            <input type = 'button' value = 'Cancel friend request' class = 'btn btn-md CFR' style='background-color:#1CCC18;color:white' data-userid = '$userid' data-accesseduserid = '$accesseduserid' />
                            </center>
                            ";    
                        }
                        else
                        {
                            $sql = "SELECT EXISTS( SELECT * FROM friend_request WHERE sender_id = $accesseduserid AND reciver_id = $userid AND Is_valid = 1)";
                            $PendingFRResult = mysqli_query($con,$sql);
                            if ($r = mysqli_fetch_array($PendingFRResult))
                            {
                                if ($r[0] == 1)
                                {
                                    echo
                                    "<center>
                                    <input type = 'button' value = 'Approve friend request' class = 'btn btn-md AFRWP' style='background-color:#1CCC18;color:white' data-userid = '$userid' data-accesseduserid = '$accesseduserid' />
                                    </center>
                                    ";
                                }
                                else
                                {
                                    echo
                                    "<center>
                                    <input type = 'button' value = 'Send friend request' class = 'btn btn-md SFR' style='background-color:#7CCC81;color:white' data-userid = '$userid' data-accesseduserid = '$accesseduserid' />
                                    </center>
                                    ";
                                }
                            }
                        }
                    }
                        $IsFriend = 0;
                }
            }
    }
    else
    {
        echo
        "<center>
        <input type = 'button' value = 'Change profile Image' class = 'btn btn-md' style='background-color:#7CCC81;color:white' data-toggle='modal' data-target='#ProfileImageModal' data-userid = '$userid'/>
        </center>
        <div id='ProfileImageModal' class='modal fade' role='dialog'>
          <div class='modal-dialog'>
            <div class='modal-content'>
              <div class='modal-header'>
                <button type='button'class='close' data-dismiss='modal'>&times;</button>
                <h4 class='modal-title'>Profile Image</h4>
              </div>
              <div class='modal-body' id = 'ModalBody'>
              <form action = 'ChangeProfileImageProc.php' method='post' enctype='multipart/form-data'>
              <input type = 'file' class = 'form-control' name ='ProfileImage' />
                <input type = 'hidden' value='$userid' name='UserID'/>
                <input id='PostBtn' type='submit' value='Save'/>
                </form>
              </div>
              <div class='modal-footer'>
                <button type='button' class='btn btn-default' data-dismiss='modal'>Close</button>
              </div>
            </div>

          </div>
        </div>
        ";
        $IsFriend = 1;
    }
	$sql = "select post_id , post_text , post_image , poster_id , poster_name , poster_image , 
            (SELECT EXISTS( SELECT * FROM post_likes as l WHERE l.liker_id = $userid AND l.post_id = p.post_id)),
			(select count(*) from post_likes where post_likes.post_id = p.post_id )
			from post p
			left outer join posters as po using (poster_id)
			where poster_id = $accesseduserid";
            if ($IsFriend == 0)
            {
                $sql.= " AND scoop_id = 1 ";
            }
            else
            {
                $sql.= " AND (scoop_id = 1 OR scoop_id = 0) ";
            }
            $sql .= "order by post_time desc";
	$posts = mysqli_query($con,$sql);
	while ($r = mysqli_fetch_array($posts))
	{
		echo 
		"<br/>
        <center>
		<div style='width:75%;'>
        <div style='float:left'>
		<img src='$r[5]' alt='PosterImage' width='50px' height = '50px'/>
		<label><a href='UserWall.php?accessedUserId=$r[3]'>$r[4]</a></label></div><div style='clear:both;'></div><br/>
		<div style='border:2px solid #7CCC81;' >
		<br/>
        <p>$r[1]</p>";
		if (!empty($r[2])){ echo "<img src='$r[2]' alt='PostImage' width='50%'/>"; }
		if ($r[7] != 0)
		{
			echo "<br/><p id = 'nolp$r[0]'><span id = 'nol$r[0]'>$r[7]</span> people Liked That .</p>";
		}
		else
		{
			echo "<br/><p id = 'nolp$r[0]' style='display:none;'><span id = 'nol$r[0]'>$r[7]</span> people Liked That .</p>";
		}
		echo "<div class='btn-group'>";
		if ($r[6] != 1)
		{
			echo "<br/><input type = 'button' value = 'Like'  class = 'btn btn-md unliked' data-userid = '$userid' data-postid = '$r[0]'  />";
		}
		else
		{
			echo "<br/><input type = 'button' value = 'Liked'   class = 'btn btn-md liked'  data-userid = '$userid' data-postid = '$r[0]' />";
		}
		echo
		"<button type='button' class='btn btn-md showcommentmodal' data-toggle='modal' data-target='#CommentModal' data-userid = '$userid' data-postid = '$r[0]' >Comment</button>
        
		</div>
		<br/>
        </div>
		</div>
		</center>
        <br/>
        <br/>
        <br/>
        <br/>
		";
	}
	mysqli_close($con);
}
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="bootstrap-3.3.7/bootstrap-3.3.7/dist/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="Community.css">
</head>
<body style='background-color:#7CCC81'>
<center>
<div style='width:75%;background-color:white'>
<?php include("LogedHeader.php"); ?>
<center>
<?php GetUserWallPosts($user,$accesseduser); ?>
<?php include("LogedFooter.php"); ?>
<?php include("AjaxLibrary.php"); ?>
</body>
</html>
<?php
}
else
{
    header("location: Registeration.php");
}
?>