<?php
session_start();
include("db_info.php");
if(isset($_GET["Email"]) && isset($_GET["Password"]))
{
    $email = $_GET["Email"];
    $password = md5($_GET["Password"]);
    $con = mysqli_connect(HOST,UN,PW,DB);
    $sql = "SELECT user_id FROM user WHERE email = '$email' and password = '$password'";
    $rslt = mysqli_query($con,$sql);
    if($r=mysqli_fetch_array($rslt))
    {
            if(isset($_GET["RememberMe"]))
            {
                $user_id = $r[0];
                $cookie_name = "user";
                $cookie_value = $email;
                setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");
                $cookie_name = "password";
                $cookie_value = $password;
                setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");
                $_SESSION["UserID"] = $user_id;
                header("location: Library.php");
            }
            else
            {
                $user_id = $r[0];
                $_SESSION["UserID"] = $user_id;
                header("location: Library.php");
            }
    }
    else
    {
        header("location: Registeration.php?error=invalid");
    }
}
else
{
    header("location: Registeration.php");
}
?>