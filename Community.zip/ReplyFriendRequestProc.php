<?php
	include("db_info.php");
	$request_id = $_POST['RequestID'];
	$reply = $_POST['Reply'];
	$con = mysqli_connect(HOST,UN,PW,DB);
	if ($reply == "Approve")
    {
        $sql = "CALL AFR ($request_id)";
    }
    else if ($reply == "Hide")
    {
        $sql = "UPDATE friend_request SET is_valid = 0 , is_approved = 0 WHERE request = $request_id ;" ;  
    }
    $rslt = mysqli_query($con , $sql);
    mysqli_close($con);
	if ($rslt == 1)
	{
		die( "done");
	}
	else
	{
		die( "error");
	}
?>