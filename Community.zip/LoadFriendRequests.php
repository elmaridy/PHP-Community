<?php
	include("db_info.php");
	$user_id = $_GET['UserID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
    $sql = "UPDATE friend_request set seen = 1 WHERE reciver_id = $user_id";
    $rslt = mysqli_query($con , $sql);
    $sql = "SELECT request,first_name,last_name,profile_image_path FROM friend_request JOIN user on (sender_id = user_id) WHERE reciver_id = $user_id And is_valid = 1 order by friend_request_time desc";
    $rslt = mysqli_query($con , $sql);
	$CommArray = array();
	while($row = mysqli_fetch_array($rslt)) 
	{
            $CommArray[] = $row;
    }
	mysqli_close($con);
	echo json_encode($CommArray);
?>