<?php
	include("db_info.php");
	$pageid = $_GET['AccessedPageID'];
    $userid = $_GET['UserID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
    $sql = "SELECT admin_id,first_name,last_name,profile_image_path FROM page_admins JOIN user ON (user_id = admin_id) WHERE page_id = $pageid And admin_id <> $userid ";
	$rslt = mysqli_query($con , $sql);
	$CommArray = array();
	while($row = mysqli_fetch_array($rslt)) 
	{
            $CommArray[] = $row;
    }
	mysqli_close($con);
	echo json_encode($CommArray);
?>