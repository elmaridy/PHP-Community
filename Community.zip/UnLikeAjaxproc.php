<?php
	include("db_info.php");
	$user_id = $_POST['UserID'];
	$post_id = $_POST['PostID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
	$sql = "DELETE FROM post_likes where post_id = $post_id and liker_id = $user_id";
	$rslt = mysqli_query($con , $sql);
	mysqli_close($con);
	if ($rslt == 1)
	{
		die( "done");
	}
	else
	{
		die( "error");
	}
?>