<?php
	include("db_info.php");
	$user_id = $_POST['UserID'];
	$group_id = $_POST['GroupID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
	$sql = "SELECT EXISTS (SELECT * FROM user_group WHERE group_id = $group_id AND user_id = $user_id AND IsAdmin = true)";
	$rslt = mysqli_query($con , $sql);
    if ($r = mysqli_fetch_array($rslt))
    {
        if($r[0] == 0)
        {
            $sql = "SELECT EXISTS (SELECT * FROM user_group WHERE group_id = $group_id AND user_id = $user_id)";
            $rslt = mysqli_query($con , $sql);
            if ($r = mysqli_fetch_array($rslt))
            {
                if($r[0] == 1)
                {
                    $sql = "UPDATE user_group SET IsAdmin = true WHERE group_id = $group_id AND user_id = $user_id)";
                    $rslt = mysqli_query($con , $sql);
                }
                else
                {
                    $sql = "INSERT INTO user_group VALUES ($user_id,$group_id,true)";
                    $rslt = mysqli_query($con , $sql);
                }
            }
            $sql = 
                "INSERT INTO notification (note_text , note_link , note_img, user_id) SELECT ( SELECT  concat('You had been added to ',(select group_name from `group` where group_id = $group_id),' group admins.')),'GroupShow.php?groupid=$group_id',(SELECT group_image_path from `group` where group_id = $group_id),$user_id" ;
            $rslt = mysqli_query($con , $sql);
            $sql = "SELECT * FROM user WHERE user_id = $user_id" ;
            $rslt = mysqli_query($con , $sql);
            mysqli_close($con);
            if ($r = mysqli_fetch_array($rslt))
            {
                echo json_encode($r);
            }
        }
        else
        {
            echo "error";
        }
    }
?>