<?php
include("db_info.php");
	$user_id = $_POST['UserID'];
	$accesseduser_id = $_POST['AccessedUserID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
	$sql = "DELETE FROM user_friends where (user_id = $user_id and friend_id = $accesseduser_id) or (user_id = $accesseduser_id and friend_id = $user_id)";
	$rslt = mysqli_query($con , $sql);
    mysqli_close($con);
    if ($rslt == 1)
	{
		die( "done");
	}
	else
	{
		die( "error");
	}
?>