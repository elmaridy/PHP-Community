<?php
	include("db_info.php");
	$post_id = $_GET['PostID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
	$sql = "SELECT post_id ,commenter_id,comm_text,comm_img, p.poster_id , p.poster_name ,p.poster_image FROM post_comments left outer join posters as p on commenter_id = p.poster_id WHERE post_id = $post_id";
	$rslt = mysqli_query($con , $sql);
	$CommArray = array();
	while($row = mysqli_fetch_array($rslt)) 
	{
            $CommArray[] = $row;
    }
	mysqli_close($con);
	echo json_encode($CommArray);
?>