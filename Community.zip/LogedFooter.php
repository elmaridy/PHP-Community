<div id="CommentModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Comments</h4>
      </div>
      <div class="modal-body" id = 'CommentModalBody'>
        <p>Some text in the modal.</p>
      </div>
      <div class="modal-footer">
	  <div>
		<input type = 'text' class = 'form-control' id = 'CommentText' /><center> <a id='UploadPhoto' href='' >UploadPhoto <span class='glyphicon glyphicon-camera'></span></a><button type="button" class="btn" id = 'SendComment' data-postid='-1' >Comment</button></center>
	  </div>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
<div class="FBar">
    <input type="hidden" data-searchType="Persons" id = "searchType"/>
        <div class="dropup" style="padding:15px">
            <center>
                <input type="text" class="form-control dropdown-toggle" data-toggle="dropdown" style="display: inline;width: 25%;" placeholder="Search" id='searchBox'/>
                <ul class="dropdown-menu dropup" style="margin-left: 32%" role="menu" aria-labelledby="menu1" >
                <div>
                    <ul class="tabs">
                     <li class="activeST">Persons</li>
                    <li class="searchTab">Pages</li>
                    <li class="searchTab">Groups</li>
                    <li class="searchTab">Blogs</li>
                    </ul>
                </div>
                <div id="searchResults">
                </div>
                </ul>
            </center>
        </div>
</div>
