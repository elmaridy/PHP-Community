<?php
	include("db_info.php");
	$user_id = $_POST['UserID'];
	$post_id = $_POST['PostID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
	$sql = "INSERT INTO post_likes (post_id , liker_id) values ( $post_id , $user_id )";
	$rslt = mysqli_query($con , $sql);
	$sql = 
        "INSERT INTO notification (note_text , note_link , note_img, user_id) SELECT  concat((select concat(first_name,' ', last_name) from user where user_id = $user_id),' ' ,'liked your post.' ),'PostShow.php?postid=$post_id',(SELECT profile_image_path from user where user_id = $user_id),(SELECT poster_id FROM post where post_id = $post_id)
        WHERE (SELECT posters.poster_id from post join posters using (poster_id) where post_id = $post_id ) != $user_id and (SELECT posters.poster_type from post join posters using (poster_id) where post_id = $post_id ) = 0" ;
	$rslt = mysqli_query($con , $sql);
	mysqli_close($con);
	if ($rslt == 1)
	{
		die( "done");
	}
	else
	{
		die( "error");
	}
?>