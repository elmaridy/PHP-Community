<?php
session_start();
session_unset();
if(isset($_COOKIE["user"]))
{
    unset($_COOKIE["user"]);
    unset($_COOKIE["password"]);
    setcookie("user",null, time()-3600,'/');
    setcookie("password",null, time()-3600,'/');
}
header("location: Registeration.php");
?>