<?php
	include("db_info.php");
	$user_id = $_POST['UserID'];
	$page_id = $_POST['AccessedPageID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
	$sql = "DELETE FROM page_admins WHERE page_id = $page_id AND admin_id = $user_id ";
	$rslt = mysqli_query($con , $sql);
	$sql = 
        "INSERT INTO notification (note_text , note_link , note_img, user_id) SELECT ( SELECT  concat('You had been removed from ',(select page_name from page where page_id = $page_id),' adminstration.')),'PageShow.php?accessedpage=$page_id',(SELECT page_image from page where page_id = $page_id),$user_id" ;
	$rslt = mysqli_query($con , $sql);
	mysqli_close($con);
	if ($rslt == 1)
	{
		die( "done");
	}
	else
	{
		die( "error");
	}
?>