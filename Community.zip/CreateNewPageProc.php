<?php
session_start();
include("db_info.php");
if(isset($_SESSION["UserID"]))
{
    $user=$_SESSION["UserID"];
if(isset($_POST["PageName"]) && isset($_POST["PageAbout"]))
{
    $pname = $_POST["PageName"];
    $pabout = $_POST["PageAbout"];
    if(!empty($_FILES['PageImage']['name']))
    {
        $image = $_FILES['PageImage'];
         $con = mysqli_connect(HOST,UN,PW,DB);
            $sql = "insert into posters(poster_name,poster_type) values('$pname',1)";
            $r = mysqli_query($con,$sql);
            $sql = "SELECT LAST_INSERT_ID();";
            $r = mysqli_query($con,$sql);
            if($p = mysqli_fetch_array($r))
            { $last_id = $p[0];}
            $d = date("Y-M-D-h-m-s");
            $target_dir = "images/posters/";
            $imageFileType = pathinfo($image["name"],PATHINFO_EXTENSION);
            $target_file = $target_dir.$last_id.$d.".".$imageFileType;
            $uploadOk = 1;
            // Check if image file is a actual image or fake image
            if(isset($_POST["submit"])) {
                $check = getimagesize($image["tmp_name"]);
                if($check !== false) {
                    echo "File is an image - " . $check["mime"] . ".";
                    $uploadOk = 1;
                } else {
                    echo "File is not an image.";
                    $uploadOk = 0;
                }
            }
            // Check if file already exists
            if (file_exists($target_file)) {
                echo "Sorry, file already exists.";
                $uploadOk = 0;
            }
            // Check file size
            if ($image["size"] > 500000) {
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" ) {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }
            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                echo "Sorry, your file was not uploaded.";
            // if everything is ok, try to upload file
            } else {
                if (!move_uploaded_file($image["tmp_name"], $target_file)) {echo "Sorry, there was an error uploading your file.";}
                else
                {
                    $sql = "UPDATE posters SET poster_image = '$target_file'WHERE poster_id = $last_id";
                    $r = mysqli_query($con,$sql);
                    $sql = "INSERT INTO page VALUES ($last_id,'$pname','$pabout',1,'$target_file')";
                    $r = mysqli_query($con,$sql);
                    $sql = "INSERT INTO page_admins VALUES ($last_id,$user)";
                    $r = mysqli_query($con,$sql);
                }
            }
            mysqli_close($con);
            header("Location: PageShow.php?accessedpage=$last_id");
        }
        else 
        {
            $image = 'images/posters/defaultP.jpg';
            $con = mysqli_connect(HOST,UN,PW,DB);
            $sql = "insert into posters(poster_name,poster_type,poster_image) values('$pname',1,'$image')";
            $r = mysqli_query($con,$sql);
            $sql = "SELECT LAST_INSERT_ID();";
            $r = mysqli_query($con,$sql);
            if($p = mysqli_fetch_array($r))
            { $last_id = $p[0];}
            $sql = "INSERT INTO page VALUES ($last_id,'$pname','$pabout',1,'$image')";
            $r = mysqli_query($con,$sql);
            $sql = "INSERT INTO page_admins VALUES ($last_id,$user)";
            $r = mysqli_query($con,$sql);
            mysqli_close($con);
            header("Location: PageShow.php?accessedpage=$last_id");
        }
    }
    else
    {
        header("Location : Library.php");
    }
}
else
{
    header("location: Registeration.php");
}
?>
