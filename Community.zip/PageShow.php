<?php
session_start();
if (isset($_SESSION["UserID"]))
{
    include("db_info.php");
    $user = $_SESSION["UserID"];
    $accessedpage = $_GET["accessedpage"];
    $con = mysqli_connect(HOST,UN,PW,DB);
    $sql = "SELECT EXISTS (SELECT * FROM page_admins WHERE page_id = $accessedpage AND admin_id = $user)";
    $check = mysqli_query($con,$sql);
    if($r = mysqli_fetch_array($check))
    {
        if($r[0] == 1)
        {
            header("location: PageShowAdmin.php?accessedpage=$accessedpage");   
        }
    }
    function GetUserWallPosts($accessedpageid , $userid)
    {
        $con = mysqli_connect(HOST,UN,PW,DB);
        $sql = "SELECT page_id,page_name,page_about,page_type_id,page_image FROM page WHERE page_id = $accessedpageid";
        $accessedpage = mysqli_query($con,$sql);
        if ($r = mysqli_fetch_array($accessedpage))
        {
            echo
            "
            <center>
                <img src = '$r[4]' alt='userimage' />
                <h1>$r[1]</h1>
            </center>
            <br/><br/><br/>
            <center>
            <div style='border-style: solid;border-radius:5px;border-width:2px;border-color:#7CCC81;width:50%'>
            $r[2]
            </div>
            </center>
            <a href='NewPage.php' style='float:right;margin-right:30px' class='btn-link'>Create Your Page.</a><br/>
            ";
        }
        $sql = "SELECT  EXISTS (SELECT * FROM user_pages WHERE user_id = $userid AND page_id = $accessedpageid)";
        $rslt = mysqli_query($con,$sql);
        if ($r = mysqli_fetch_array($rslt))
        {
            if ($r[0] == 1)
            {
                echo
                "<input type = 'button' value = 'Liked' class = 'btn btn-md ULP' style= 'background-color:#5b92e3;color:white' data-userid = '$userid' data-accessedpageid = '$accessedpageid' />";
            }
            else
            {
                echo
                "<input type = 'button' value = 'Like' class = 'btn btn-md LP' style= 'background-color:#7CCC81;color:white' data-userid = '$userid' data-accessedpageid = '$accessedpageid' />";
            }
        }
        $sql = "SELECT COUNT(*) FROM user_pages WHERE page_id = $accessedpageid";
        $rslt = mysqli_query($con,$sql);
        if ($r = mysqli_fetch_array($rslt))
        {
            echo
            "<br/><br/>
            <div style='clear:both'></div>
            <div style='width:25%;float:left;border-radius:5px;border-style:solid;border-width:2px;border-color:#7CCC81;margin-left:125px'>
            <img src='images/ServerImages/group-128.png' alt='PeopleImage' style='float:left' width='40px' height='40px'/>  $r[0] People liked this page
            </div>
            <div style='clear:both'></div><hr/>
            ";
        }
        $sql = "select post_id , post_text , post_image , poster_id , poster_name , poster_image , 
                (SELECT EXISTS( SELECT * FROM post_likes as l WHERE l.liker_id = $userid AND l.post_id = p.post_id)),
                (select count(*) from post_likes where post_likes.post_id = p.post_id ),poster_type
                from post p
                left outer join posters as po using (poster_id)
                where poster_id = $accessedpageid
                order by post_time desc";
        $posts = mysqli_query($con,$sql);
        while ($r = mysqli_fetch_array($posts))
        {
           echo 
            "<br/>
            <center>
            <div style='width:75%;'>
            <div style='float:left'>
            <img src='$r[5]' alt='PosterImage' width='50px' height = '50px'/>";
            if($r[8] == 0)
            {
                echo "<label><a href='UserWall.php?accesseduser=$r[3]'>$r[4]</a></label>";
            }
            else if ($r[8] == 1)
            {
                echo "<label><a href='PageShow.php?accessedpage=$r[3]'>$r[4]</a></label>";
            }
            echo
            "</div><div style='clear:both;'></div><br/>
            <div style='border:2px solid #7CCC81;' >
            <br/>
            <p>$r[1]</p>";
            if (!empty($r[2])){ echo "<img src='$r[2]' alt='PostImage' width='50%'/>"; }
            if ($r[7] != 0)
            {
                echo "<br/><p id = 'nolp$r[0]'><span id = 'nol$r[0]'>$r[7]</span> people Liked That .</p>";
            }
            else
            {
                echo "<br/><p id = 'nolp$r[0]' style='display:none;'><span id = 'nol$r[0]'>$r[7]</span> people Liked That .</p>";
            }
            if ($r[6] != 1)
            {
                echo "<br/><input type = 'button' value = 'Like'  class = 'btn btn-md unliked' data-userid = '$userid' data-postid = '$r[0]'  />";
            }
            else
            {
                echo "<br/><input type = 'button' value = 'Liked'   class = 'btn btn-md liked'  data-userid = '$userid' data-postid = '$r[0]' />";
            }
            echo
            "<button type='button' class='btn btn-md showcommentmodal' data-toggle='modal' data-target='#CommentModal' data-userid = '$userid' data-postid = '$r[0]' >Comment</button>
            <br/>
            </div>
            </div>
            </center>
            <br/>
            <br/>
            <br/>
            <br/>
            ";
        }
        mysqli_close($con);
    }
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="Community.css">
</head>
<body style='background-color:#7CCC81'>
<center>
<div style='width:75%;background-color:white'>
<?php include("LogedHeader.php"); ?>
<center>
<?php GetUserWallPosts($accessedpage , $user); ?>
<?php include("LogedFooter.php"); ?>
<?php include("AjaxLibrary.php"); ?>
</body>
</html>
<?php
}
else
{
    header("location: Registeration.php");
}
?>