<div class="HBar">
    <div style="display: inline">
        <div>
            <a href="Library.php" class="btn btn-link" style="margin-top:10px;float:right;color:#7CCC81;"><span class="glyphicon glyphicon-home"></span></a>
            <a href="Logout.php" class="btn btn-link" style="margin-top:10px;float:right;color:#7CCC81;"><span class="glyphicon glyphicon-log-out"></span></a>
        </div>
        <input type="hidden" data-userid="<?php echo $user; ?>" id = "UserID"/>
        <div class="dropdown" align="left" style="padding:15px;float:left">
            <a id="notifico" class="dropdown-toggle" style="float:left" data-userid="<?php echo $user; ?>" data-toggle="dropdown" ><span class="glyphicon glyphicon-globe"></span><span class="caret"></span></a>
        <ul class="dropdown-menu" role="menu" aria-labelledby="menu1" id="notifs"></ul>
        </div>
        <div class="dropdown" align="left" style="padding:15px;">
            <a id="frico" class="dropdown-toggle" style="float:left" data-userid="<?php echo $user; ?>" data-toggle="dropdown" ><span class="glyphicon glyphicon-user"></span><span class="caret"></span></a>
        <ul class="dropdown-menu" role="menu" aria-labelledby="menu1" id="friendrequests"></ul>
        </div>
    </div>
</div>
<br/><br/><br/>