<?php
session_start();
if (isset($_SESSION["UserID"]))
{
    include("db_info.php");
    $user = $_SESSION["UserID"]; 
    function PostWI ($posterid,$scoopid,$text)
    {
            $con = mysqli_connect(HOST,UN,PW,DB);
            $sql = "insert into post(poster_id,scoop_id,post_text) values($posterid,$scoopid,'$text')";
            $r = mysqli_query($con,$sql);
            mysqli_close($con);
    }
    function Post($posterid,$scoopid,$text,$image)
    {
            $con = mysqli_connect(HOST,UN,PW,DB);
            $sql = "insert into post(poster_id,scoop_id,post_text) values($posterid,$scoopid,'$text')";
            $r = mysqli_query($con,$sql);
            $sql = "SELECT LAST_INSERT_ID();";
            $r = mysqli_query($con,$sql);
            if($p = mysqli_fetch_array($r))
            { $last_id = $p[0];}
            $target_dir = "images/posts/";
            $imageFileType = pathinfo($image["name"],PATHINFO_EXTENSION);
            $target_file = $target_dir .$last_id.".".$imageFileType;
            $uploadOk = 1;
            // Check if image file is a actual image or fake image
            if(isset($_POST["submit"])) {
                $check = getimagesize($image["tmp_name"]);
                if($check !== false) {
                    echo "File is an image - " . $check["mime"] . ".";
                    $uploadOk = 1;
                } else {
                    echo "File is not an image.";
                    $uploadOk = 0;
                }
            }
            // Check if file already exists
            if (file_exists($target_file)) {
                echo "Sorry, file already exists.";
                $uploadOk = 0;
            }
            // Check file size
            if ($image["size"] > 500000) {
                echo "Sorry, your file is too large.";
                $uploadOk = 0;
            }
            // Allow certain file formats
            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
            && $imageFileType != "gif" ) {
                echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                $uploadOk = 0;
            }
            // Check if $uploadOk is set to 0 by an error
            if ($uploadOk == 0) {
                echo "Sorry, your file was not uploaded.";
            // if everything is ok, try to upload file
            } else {
                if (!move_uploaded_file($image["tmp_name"], $target_file)) {echo "Sorry, there was an error uploading your file.";}
            }
            $postimage = "images/posts/".$last_id.".".$imageFileType;
            $sql = "update post set post_image = '$postimage' where post_id = $last_id";
            $r = mysqli_query($con,$sql);
            mysqli_close($con);
        }
    if(!empty($_POST['PostText']) && !empty($_POST['Scoop']))
    {
        $scoop = $_POST['Scoop'];
            if(!empty($_FILES['Image']['name']))
            {
                if(isset($_POST["Page"]))
                {
                    $page = $_POST["Page"];
                    Post($page,$scoop,$_POST['PostText'],$_FILES['Image']);
                    header("location: PageShowAdmin.php?accessedpage=$page");
                }
                else
                {
                    Post($user,$scoop,$_POST['PostText'],$_FILES['Image']);
                    header("location: Library.php");
                }
            }
            else 
            {
                if(isset($_POST["Page"]))
                {
                    $page = $_POST["Page"];
                    PostWI($page,$scoop,$_POST['PostText']);
                    header("location: PageShowAdmin.php?accessedpage=$page");
                }
                else
                {
                    PostWI($user,$scoop,$_POST['PostText']);
                    header("location: Library.php");
                }
            }
    }
    else
    {
        header("location: Library.php");
    }
}
else
{
    header("location: Registeration.php");
}
?>