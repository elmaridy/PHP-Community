<?php
	include("db_info.php");
	$user_id = $_GET['UserID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
    $sql = "SELECT EXISTS( SELECT * FROM notification WHERE user_id = $user_id and ISRead = 0)";
	$rslt = mysqli_query($con , $sql);
    $CommArray = array();
    mysqli_close($con);
    if($row = mysqli_fetch_array($rslt))
    {
        echo $row[0];
    }
?>