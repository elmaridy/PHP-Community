<?php
define('HOST','localhost');
define('UN','root');
define('PW','');
define('DB','community');
?>