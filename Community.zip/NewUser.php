<?php
session_start();
include("db_info.php");
if(isset($_POST["FName"]) && isset($_POST["LName"]) && isset($_POST["Email"]) && isset($_POST["Password"]) && isset($_POST["BirthDate"]) && isset($_POST["Gender"]) )
{
    $fname = $_POST["FName"];
    $lname = $_POST["LName"];
    $email = $_POST["Email"];
    $password = md5($_POST["Password"]);
    $DOB = $_POST["BirthDate"];
    $gender = $_POST["Gender"];
    if($gender == "M")
    {
        $img = "images/posters/defaultM.jpg";
    }
    else if($gender == "F")
    {
        $img = "images/posters/defaultF.jpg";
    }
    $con = mysqli_connect(HOST,UN,PW,DB);
    $sql = "SELECT EXISTS (SELECT email FROM user WHERE email = '$email')";
    $rslt = mysqli_query($con,$sql);
    if($r = mysqli_fetch_array($rslt))
    {
        if($r[0] == 1)
        {
            header("location: Registeration.php");
        }
    }
    $sql ="INSERT INTO posters(poster_name,poster_type,poster_image) VALUES ('$fname $lname',0,'$img')";
    $rslt = mysqli_query($con,$sql);
    $sql = "SELECT LAST_INSERT_ID();";
    $r = mysqli_query($con,$sql);
    if($p = mysqli_fetch_array($r))
    { $last_id = $p[0];}
    $sql = "INSERT INTO user VALUES ($last_id,'$fname','$lname','$email','$password','$img',1,'$gender','$DOB')";
    $rslt = mysqli_query($con,$sql);
    mysqli_close($con);
    $_SESSION["UserID"] = $last_id;
    header("location: Library.php");
}
else
{
    header("location: Registeration.php");
}
?>