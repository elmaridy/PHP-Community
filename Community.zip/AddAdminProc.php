<?php
	include("db_info.php");
	$user_id = $_POST['UserID'];
	$page_id = $_POST['AccessedPageID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
	$sql = "SELECT EXISTS (SELECT * FROM page_admins WHERE page_id = $page_id AND admin_id = $user_id)";
	$rslt = mysqli_query($con , $sql);
    if ($r = mysqli_fetch_array($rslt))
    {
        if($r[0] == 0)
        {
            $sql = "INSERT INTO page_admins SELECT $page_id , $user_id WHERE (SELECT EXISTS (SELECT * FROM page_admins WHERE page_id = $page_id AND admin_id = $user_id )) = 0";
            $rslt = mysqli_query($con , $sql);
            $sql = 
                "INSERT INTO notification (note_text , note_link , note_img, user_id) SELECT ( SELECT  concat('You had been added to ',(select page_name from page where page_id = $page_id),' admins.')),'PageShow.php?accessedpage=$page_id',(SELECT page_image from page where page_id = $page_id),$user_id" ;
            $rslt = mysqli_query($con , $sql);
            $sql = "SELECT * FROM user WHERE user_id = $user_id" ;
            $rslt = mysqli_query($con , $sql);
            mysqli_close($con);
            if ($r = mysqli_fetch_array($rslt))
            {
                echo json_encode($r);
            }
        }
        else
        {
            echo "error";
        }
    }
?>