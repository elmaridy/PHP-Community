<?php
include("db_info.php");
if	(isset($_POST['PostID']) && isset($_POST['CommentText']))
{
	$postid = $_POST['PostID'];
	$commenterid = 1;
	$text = $_POST['CommentText'];
	$con = mysqli_connect(HOST,UN,PW,DB);
	$sql = "insert into post_comments(post_id,commenter_id,comm_text) values($postid,$commenterid,'$text')";
	$r = mysqli_query($con,$sql);
	if(!empty($_FILES['Image']))
	{
		$sql = "SELECT LAST_INSERT_ID();";
		$r = mysqli_query($con,$sql);
		if($p = mysqli_fetch_array($r))
		{ $last_id = $p[0];}
		$target_dir = "images/CommentsImages/";
		$imageFileType = pathinfo($_FILES['Image']['name'],PATHINFO_EXTENSION);
		$target_file = $target_dir .$last_id.".".$imageFileType;
		$uploadOk = 1;
		if(isset($_POST["submit"])) {
			$check = getimagesize($_FILES['Image']["tmp_name"]);
			if($check !== false) {
				echo "File is an image - " . $check["mime"] . ".";
				$uploadOk = 1;
			} else {
				echo "File is not an image.";
				$uploadOk = 0;
			}
		}
		if (file_exists($target_file)) {
			echo "Sorry, file already exists.";
			$uploadOk = 0;
		}
		if ($_FILES['Image']["size"] > 500000) {
			echo "Sorry, your file is too large.";
			$uploadOk = 0;
		}
		if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
		&& $imageFileType != "gif" ) {
			echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			$uploadOk = 0;
		}
		if ($uploadOk == 0) {
			echo "Sorry, your file was not uploaded.";
		} else {
			if (move_uploaded_file($_FILES['Image']["tmp_name"], $target_file)) {} else {
				echo "Sorry, there was an error uploading your file.";
			}
		}
		$postimage = "images/CommentsImages/".$last_id.".".$imageFileType;
		$sql = "update post_comments set comm_img = '$postimage' where post_comm_id = $last_id";
		$r = mysqli_query($con,$sql);
        $d=date('Y-m-d H:i:s');
	   $sql = 
        "INSERT INTO notification (note_text , note_link , note_img, user_id , note_time) SELECT  concat((select concat(first_name,' ', last_name) from user where user_id = $user_id),' ' ,'commented on your post.' ),'PostShow.php?postid=$post_id' ,(SELECT profile_image_path from user where user_id = $user_id),(SELECT poster_id FROM post where post_id = $post_id) ,'$d' 
        WHERE (SELECT posters.poster_id from post join posters using (poster_id) where post_id = $post_id ) != $user_id and (SELECT posters.poster_type from post join posters using (poster_id) where post_id = $post_id ) = 0" ;
	   $rslt = mysqli_query($con , $sql);
		mysqli_close($con);
	}
	else
	{
		mysqli_close($con);
	}
	header('Location: Library.php');
}
else
{
	header('Location: Library.php');
}

?>