<?php
	include("db_info.php");
	$groupid = $_GET['GroupID'];
    $userid = $_GET['UserID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
    $sql = "SELECT user_group.user_id,first_name,last_name,profile_image_path FROM user_group JOIN user using (user_id) WHERE group_id = $groupid AND user_id <> $userid AND IsAdmin = true ";
	$rslt = mysqli_query($con , $sql);
	$CommArray = array();
	while($row = mysqli_fetch_array($rslt)) 
	{
            $CommArray[] = $row;
    }
	mysqli_close($con);
	echo json_encode($CommArray);
?>