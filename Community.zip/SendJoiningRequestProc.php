<?php
include("db_info.php");
	$user_id = $_POST['UserID'];
	$group_id = $_POST['GroupID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
	$sql = " INSERT INTO joining_request (sender_id,group_id,is_valid,is_approved) values ($user_id, $group_id,true,false)";
	$rslt = mysqli_query($con , $sql);
    mysqli_close($con);
    if ($rslt == 1)
	{
		die( "done");
	}
	else
	{
		die( "error");
	}
?>