<?php
	include("db_info.php");
	$request_id = $_POST['RequestID'];
	$reply = $_POST['Reply'];
	$con = mysqli_connect(HOST,UN,PW,DB);
	if ($reply == "Approve")
    {
        $sql = "INSERT INTO user_group VALUES ((SELECT sender_id FROM joining_request WHERE request_id = $request_id),(SELECT group_id FROM joining_request WHERE request_id = $request_id),false)";
        $rslt = mysqli_query($con , $sql);
        $sql =
        "INSERT INTO notification (note_text , note_link , note_img, user_id) SELECT ( SELECT  concat('You had been added to ',(select group_name from `group` where group_id = (SELECT group_id FROM joining_request WHERE request_id = $request_id)),' group members.')),'GroupShow.php?groupid=(SELECT group_id FROM joining_request WHERE request_id = $request_id)',(SELECT group_image_path from `group` where group_id = (SELECT group_id FROM joining_request WHERE request_id = $request_id)),(SELECT sender_id FROM joining_request WHERE request_id = $request_id)";
        $rslt = mysqli_query($con , $sql);
        $sql = "UPDATE joining_request SET is_valid = 0 , is_approved = 1 WHERE request_id = $request_id";
        $rslt = mysqli_query($con , $sql);
        $sql = "SELECT * FROM user WHERE user_id = (SELECT sender_id FROM joining_request WHERE request_id = $request_id)" ;
        $rslt = mysqli_query($con , $sql);
        mysqli_close($con);
        if ($r = mysqli_fetch_array($rslt))
        {
            echo json_encode($r);
        }
    }
    else if ($reply == "Hide")
    {
        $sql = "UPDATE joining_request SET is_valid = 0 , is_approved = 0 WHERE request_id = $request_id";
        $rslt = mysqli_query($con , $sql);
        mysqli_close($con);
    }
?>