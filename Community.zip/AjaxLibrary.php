<script src="jquery-3.1.1.min"></script>
<script>
  	function getCommentTemplate(PosterName,PosterImg,CommentText,CommentImage)
	{
		var temp = "<div><hr/><img src ='"+PosterImg+"' alt = 'CommenterID' width='40px' height = '40px' style='float:left;margin-left:10px' /><label style='float:left;margin-left:10px'>"+PosterName+"</label><div style='clear:both' ></div><br/><br/><p>"+CommentText+"</p>";
		if(CommentImage != null)
		{
			temp += "<img src='"+CommentImage+"' alt = 'CommentImage' />";
		}
		temp += "<hr/></div>";
		return temp	;	
	}
    function getNotifTemplate(NotiText,NotiLink,NotiImg)
	{
		var temp ="<li role='presentation'><a role='menuitem' tabindex='-1' href='"+NotiLink+"'><img src='"+NotiImg+"' width='50px' height = '50px'/>&nbsp;<label>"+NotiText+"</label></a></li><li role='presentation' class='divider'></li>";
		return temp	;	
	}
    function getFriendRequestTemplate(RequestID,UserFirstName,UserLastName,UserImg)
    {
        var temp ="<li role='presentation'><img src='"+UserImg+"' width='50px' height = '50px' style='float:left;margin-top:20px;margin-left:10px'/>&nbsp;<div style='width:300px'><center><label>"+UserFirstName+" "+UserLastName+"</label><br/><input type = 'button' value = 'Approve'  class = 'btn btn-sm AFR' style='background-color:#7CCC81;color:white' data-requestid='"+RequestID+"' /><input type = 'button' value = 'Hide'  class = 'btn btn-sm HFR' style='background-color:#5b92e3;color:white' data-requestid ='"+RequestID+"'  /></center></div></li><li role='presentation' class='divider'></li>";
		return temp	;	
    }
    function getJoiningRequestTemplate(RequestID,UserFirstName,UserLastName,UserImg,GroupID)
    {
        var temp ="<li role='presentation'><img src='"+UserImg+"' width='50px' height = '50px' style='float:left;margin-top:20px;margin-left:10px'/>&nbsp;<div style='width:300px'><center><label>"+UserFirstName+" "+UserLastName+"</label><br/><input type = 'button' value = 'Approve'  class = 'btn btn-sm AJR' style='background-color:#7CCC81;color:white' data-requestid='"+RequestID+"' data-groupid='"+GroupID+"' /><input type = 'button' value = 'Hide'  class = 'btn btn-sm HJR' style='background-color:#5b92e3;color:white' data-requestid ='"+RequestID+"' /></center></div></li><li role='presentation' class='divider'></li>";
		return temp	;	
    }
    function getSearchUserTemplate(ID,FName,LName,Image)
	{
		var temp ="<div><hr/><a href='UserWall.php?accesseduser="+ID+"'><img src ='"+Image+"' alt = 'Result' width='30px' height = '30px' /><label>"+FName+" "+LName +"</label></a></div>"
		return temp	;
	}
    function getSearchAdminTemplate(ID,FName,LName,Image,PageID)
	{
		var temp ="<div><hr/><a href='UserWall.php?accesseduser="+ID+"' style='float:left'><img src ='"+Image+"' alt = 'Result' width='30px' height = '30px' style='margin:5px' /><label>"+FName+" "+LName +"</label></a><input type='button' value='Add' class='btn btn-sm AddAdmin' style='float:right;margin:5px;color:white;background-color:#7CCC81' data-userid = '"+ID+"' data-pageid = '"+PageID+"'/></div><div style='clear:both'></div>"
		return temp	;
	}
    function getSearchGroupAdminTemplate(ID,FName,LName,Image,GroupID)
	{
		var temp ="<div><hr/><a href='UserWall.php?accesseduser="+ID+"' style='float:left'><img src ='"+Image+"' alt = 'Result' width='30px' height = '30px' style='margin:5px' /><label>"+FName+" "+LName +"</label></a><input type='button' value='Add' class='btn btn-sm AddGroupAdmin' style='float:right;margin:5px;color:white;background-color:#7CCC81' data-userid = '"+ID+"' data-groupid = '"+GroupID+"'/></div><div style='clear:both'></div>"
		return temp	;
	}
    function getSearchGroupMemberTemplate(ID,FName,LName,Image,GroupID)
	{
		var temp ="<div><hr/><a href='UserWall.php?accesseduser="+ID+"' style='float:left'><img src ='"+Image+"' alt = 'Result' width='30px' height = '30px' style='margin:5px' /><label>"+FName+" "+LName +"</label></a><input type='button' value='Add' class='btn btn-sm AddGroupMember' style='float:right;margin:5px;color:white;background-color:#7CCC81' data-userid = '"+ID+"' data-groupid = '"+GroupID+"'/></div><div style='clear:both'></div>"
		return temp	;
	}
    function getAdminTemplate(ID,FName,LName,Image,PageID)
    {
        var temp ="<div><hr/><a href='UserWall.php?accesseduser="+ID+"' style='float:left'><img src ='"+Image+"' alt = 'Result' width='30px' height = '30px' style='margin:5px' /><label>"+FName+" "+LName +"</label></a><input type='button' value='Remove' class='btn btn-sm RemoveAdmin' style='float:right;margin:5px;color:white;background-color:#5b92e3' data-userid = '"+ID+"' data-pageid = '"+PageID+"'/></div><div style='clear:both'></div>"
		return temp	;
    }
    function getGroupAdminTemplate(ID,FName,LName,Image,GroupID)
    {
        var temp ="<div><hr/><a href='UserWall.php?accesseduser="+ID+"' style='float:left'><img src ='"+Image+"' alt = 'Result' width='30px' height = '30px' style='margin:5px' /><label>"+FName+" "+LName +"</label></a><input type='button' value='Remove' class='btn btn-sm RemoveGroupAdmin' style='float:right;margin:5px;color:white;background-color:#5b92e3' data-userid = '"+ID+"' data-groupid = '"+GroupID+"'/></div><div style='clear:both'></div>"
		return temp	;
    }
    function getGroupMemberTemplate(ID,FName,LName,Image,GroupID)
    {
        var temp ="<div><hr/><a href='UserWall.php?accesseduser="+ID+"' style='float:left'><img src ='"+Image+"' alt = 'Result' width='30px' height = '30px' style='margin:5px' /><label>"+FName+" "+LName +"</label></a><input type='button' value='Remove' class='btn btn-sm RemoveGroupMember' style='float:right;margin:5px;color:white;background-color:#5b92e3' data-userid = '"+ID+"' data-groupid = '"+GroupID+"'/></div><div style='clear:both'></div>"
		return temp	;
    }
    function getSearchPageTemplate(ID,Name,Image)
	{
		var temp ="<div><hr/><a href='PageShow.php?accessedpage="+ID+"'><img src ='"+Image+"' alt = 'Result' width='30px' height = '30px' /><label>"+Name+"</label></a></div>"
		return temp	;	
	}
    function getSearchGroupTemplate(ID,Name,Image)
	{
		var temp ="<div><hr/><a href='GroupShow.php?groupid="+ID+"'><img src ='"+Image+"' alt = 'Result' width='30px' height = '30px' /><label style='margin:5px'>"+Name+"</label></a></div>"
		return temp	;	
	}
    function getSearchBlogTemplate(ID,Name,Image)
	{
		var temp ="<div><hr/><a href='BlogShow.php?blogid="+ID+"'><img src ='"+Image+"' alt = 'Result' width='30px' height = '30px' /><label>"+Name+"</label></a></div>"
		return temp	;	
	}
	$( "body" ).delegate( ".unliked", "click", function() {
		var UserID = $(this).attr('data-userid');
		var PostID = $(this).attr('data-postid');
		$.ajax({
				type : 'POST',
				url  : 'LikeAjaxproc.php',
				data : {'UserID' : UserID , 'PostID' : PostID },
				success: function(data){
					if(data =="error")
                    {
						alert("Sorry , but there's something went wrong !!");
					}
				}
				
			});
			$(this).fadeOut(200,function(){
				var $nol = parseInt($('#nol'+PostID).html());
				$nol += 1 ;
				$('#nol'+PostID).html($nol);
				$('#nolp'+PostID).fadeIn(200,function(){
				$('#nolp'+PostID).css("display", "inline");	
				});
				$(this).val("Liked")
				$(this).removeClass( "unliked" ).addClass( "btn btn-md liked" );
				$(this).fadeIn(200);
			});
	});
    $( "body" ).delegate( ".liked", "click", function() {
		var UserID = $(this).attr('data-userid');
		var PostID = $(this).attr('data-postid');
		$.ajax({
				type : 'POST',
				url  : 'UnLikeAjaxproc.php',
				data : {'UserID' : UserID , 'PostID' : PostID },
				success: function(data){
					if(data =="error")
					{
						alert("Sorry , but there's something went wrong !!");
					}
				}
				
			});
			$(this).fadeOut(200,function(){
				var $nol = parseInt($('#nol'+PostID).html());
				if ($nol == 1)
				{
					$nol -= 1 ;
					$('#nol'+PostID).html($nol);
					$('#nolp'+PostID).fadeOut(200);
				}
				else
				{
					$nol -= 1 ;
					$('#nol'+PostID).html($nol);
				}
				$(this).val("Like")
				$(this).removeClass( "liked" ).addClass( "btn btn-md unliked" );
				$(this).fadeIn(200);
			});
	});
	$( "body" ).delegate( ".showcommentmodal", "click", function() {
		var UserID = $(this).attr('data-userid');
		var PostID = $(this).attr('data-postid');
		$.ajax({
				type : 'GET',
				url  : 'LoadPostComments.php',
				data : {'PostID' : PostID },
				success: function(data){
					var arr = jQuery.parseJSON(data);
					var comments = "" ;
					$.each(arr, function () {
						comments += getCommentTemplate(this[5],this[6],this[2],this[3]);
					});
					if (comments == "" )
					{
						comments = "No Comments Found";
					}
					$('#CommentModal').find('#CommentModalBody').html(comments);
					$('#UploadPhoto').attr('href',"PostShow.php?postid="+PostID)
					$("#SendComment").attr('data-userid',UserID);
					$("#SendComment").attr('data-postid',PostID);
				}
	});
	});
	$( "body" ).delegate( "#SendComment", "click", function() {
		var UserID = $(this).attr('data-userid');
		var PostID = $(this).attr('data-postid');
		var CommentText = $('#CommentText').val();
		$.ajax({
				type : 'POST',
				url  : 'PostComment.php',
				data : {'PostID' : PostID , 'UserID' :UserID , 'CommentText' : CommentText  },
				success: function(data){
                    var arr = jQuery.parseJSON(data);
                    var Comments = $("#CommentModalBody").html();
                    var name = arr[0]+" "+arr[1];
				    Comments += getCommentTemplate(name,arr[2],$('#CommentText').val(),null);
                    $("#CommentModalBody").html("");
                    $("#CommentModalBody").html(Comments);
					$('#CommentText').val("");
				}
	});
	});
    $( "body" ).delegate( '.tabs .searchTab', "click", function(event){
        $(".activeST").removeClass("activeST").addClass("searchTab")
        $(this).removeClass("searchTab").addClass("activeST");
        $('#searchType').attr('data-searchType',$(this).html());
        $("#searchBox").focus();
        event.stopPropagation();
    });
    $("#notifico").on("click", function() {
		var UserID = $(this).attr('data-userid');
		$.ajax({
				type : 'GET',
				url  : 'LoadNotification.php',
				data : {'UserID' : UserID},
				success: function(data)
                {
				    	var arr = jQuery.parseJSON(data);
                        var Notifs = "" ;
					$.each(arr, function () {
						Notifs += getNotifTemplate(this[0],this[1],this[2]);
					});
					if (Notifs == "" )
					{
						Notifs = "No Notifications Found";
					}
                    $('#notifico').css('color', '#7CCC81');
                    $('#notifs').html(Notifs);
				}
	});
	});
    $("#notifico").ready(function Check(UserID) {
		var UserID =  $("#UserID").attr('data-userid');
		$.ajax({
				type : 'GET',
				url  : 'CheckUnReadNotifications.php',
				data : {'UserID' : UserID},
				success: function(data)
                {
						if(data ==1)
                        {
                            $('#notifico').css('color', 'red');
                        }	
				}
	});
	});
    $("body").delegate('#searchBox',"input",(function(){
        var Stype =$('#searchType').attr('data-searchType');
        if (Stype == "Persons")
        {
            var target = "user";    
        }
        else if (Stype == "Pages")
        {
            var target = "page";
        }
        else if (Stype == "Groups")
        {
            var target = "group";
        }
        else if (Stype == "Blogs")
        {
            var target = "blog";
        }
        else
        {
            alert("Error");
        }
        var text = $(this).val();
        $.ajax({
				type : 'GET',
				url  : 'Search.php',
				data : {'Text' : text , 'Stype' : target },
				success: function(data){
					var arr = jQuery.parseJSON(data);
					var Result = "" ;
                    if(text == "")
                    {
                        Result="";
                    }
                    else if(Stype == "Persons")
                    {
					   $.each(arr, function () {
						  Result += getSearchUserTemplate(this[0],this[1],this[2],this[3]);
					   });
                    }
                    else if (Stype == "Pages")
                    {
                        $.each(arr, function () {
						  Result += getSearchPageTemplate(this[0],this[1],this[2]);
					   });

                    }
                    else if (Stype == "Groups")
                    {
                        $.each(arr, function () {
						  Result += getSearchGroupTemplate(this[0],this[1],this[2]);
					   });

                    }
                    else if (Stype == "Blogs")
                    {
                        $.each(arr, function () {
						  Result += getSearchBlogTemplate(this[0],this[1],this[2]);
					   });

                    }
					if (Result == "" )
					{
						Result = "No Results Found";
					}
                    $("#searchResults").html(Result);
				}
	});
    }));
    $("body").delegate('.UF',"click",function(){
        var UserID = $(this).attr('data-userid');
		var AccessedUserID = $(this).attr('data-accesseduserid');
        $.ajax({
				type : 'POST',
				url  : 'UnFriendProc.php',
				data : {'UserID' : UserID , 'AccessedUserID' : AccessedUserID },
				success: function(data){
					if(data =="error")
                    {
						alert("Sorry , but there's something went wrong !!");
					}
				}
			});
        $(this).fadeOut(200,function(){
				$(this).val("Send friend request")
                $(this).css('background-color', '#7CCC81');
				$(this).removeClass( "UF" ).addClass( "btn btn-md SFR" );
				$(this).fadeIn(200);
            });
    });
    $("body").delegate('.SFR',"click",function(){
        var UserID = $(this).attr('data-userid');
		var AccessedUserID = $(this).attr('data-accesseduserid');
        $.ajax({
				type : 'POST',
				url  : 'SendFriendRequestProc.php',
				data : {'UserID' : UserID , 'AccessedUserID' : AccessedUserID },
				success: function(data){
                    if(data =="error")
                    {
						alert("Sorry , but there's something went wrong !!");
					}
				}
			});
        $(this).fadeOut(200,function(){
				$(this).val("Cancel friend request")
                $(this).css('background-color', '#1CCC18');
				$(this).removeClass( "SFR" ).addClass( "btn btn-md CFR" );
				$(this).fadeIn(200);
            });
    });
    $("body").delegate('.CFR',"click",function(){
        var UserID = $(this).attr('data-userid');
		var AccessedUserID = $(this).attr('data-accesseduserid');
        $.ajax({
				type : 'POST',
				url  : 'CancelFriendRequestProc.php',
				data : {'UserID' : UserID , 'AccessedUserID' : AccessedUserID },
				success: function(data){
					if(data =="error")
                    {
						alert("Sorry , but there's something went wrong !!");
					}
				}
			});
        $(this).fadeOut(200,function(){
				$(this).val("Send friend request")
                $(this).css('background-color', '#7CCC81');
				$(this).removeClass( "CFR" ).addClass( "btn btn-md SFR" );
				$(this).fadeIn(200);
            });
    });
    $("#frico").on("click", function() {
		var UserID = $(this).attr('data-userid');
		$.ajax({
				type : 'GET',
				url  : 'LoadFriendRequests.php',
				data : {'UserID' : UserID},
				success: function(data)
                {
				    	var arr = jQuery.parseJSON(data);
                        var FriendRequests = "" ;
					$.each(arr, function () {
						FriendRequests += getFriendRequestTemplate(this[0],this[1],this[2],this[3]);
					});
					if (FriendRequests == "" )
					{
						FriendRequests = "No Friend Requests";
					}
                    $('#frico').css('color', '#7CCC81');
                    $('#friendrequests').html(FriendRequests);
				}
	});
	});
    $("#frico").ready(function CheckFR(UserID) {
		var UserID =  $("#UserID").attr('data-userid');
		$.ajax({
				type : 'GET',
				url  : 'CheckUnReadFriendRequests.php',
				data : {'UserID' : UserID},
				success: function(data)
                {
						if(data ==1)
                        {
                            $('#frico').css('color', 'red');
                        }	
				}
	});
	});
    $("body").delegate(".AFR","click",function(){
        var RequestID = $(this).attr('data-requestid');
        var Reply = 'Approve';
        $.ajax({
				type : 'POST',
				url  : 'ReplyFriendRequestproc.php',
				data : {'RequestID' : RequestID , 'Reply' : Reply },
				success: function(data){
                     if(data =="error")
                    {
						alert("Sorry , but there's something went wrong !!");
					}   
				}
	}); 
        $(this).closest("div").fadeOut(200,function(){
				$(this).closest("div").html("This request had been Approved");
                $(this).closest("div").css("padding","10px")
                $(this).closest("div").fadeIn(200);
            });
    });
    $("body").delegate(".HFR","click",function(){
        var RequestID = $(this).attr('data-requestid');
        var Reply = 'Hide';
        $.ajax({
				type : 'POST',
				url  : 'ReplyFriendRequestproc.php',
				data : {'RequestID' : RequestID , 'Reply' : Reply },
				success: function(data){
                     if(data =="error")
                    {
						alert("Sorry , but there's something went wrong !!");
					}   
				}
	       });
            $(this).closest("div").fadeOut(200,function(){
				$(this).closest("div").html("This request had been rejected");
                $(this).closest("div").css("padding","10px")
                $(this).closest("div").fadeIn(200);
            });
    });
    $("body").delegate(".AFRWP","click",function(){
        var UserID = $(this).attr('data-userid');
		var AccessedUserID = $(this).attr('data-accesseduserid');
        $.ajax({
				type : 'POST',
				url  : 'ApproveFriendRequest.php',
				data : {'AccessedUserID' : AccessedUserID , 'UserID' : UserID },
				success: function(data){
                     if(data =="error")
                    {
						alert("Sorry , but there's something went wrong !!");
					}   
				}
	}); 
        $(this).val("Unfriend")
                $(this).css('background-color', '#5b92e3');
				$(this).removeClass( "AFRWP" ).addClass( "btn btn-md UF" );
				$(this).fadeIn(200);
    });
    $("body").delegate('#Emailtxt',"blur",(function(){
        var Email = $("#Emailtxt").val();
        $.ajax({
				type : 'GET',
				url  : 'CheckEmailExistance.php',
				data : {'Email' :Email },
				success: function(data){
                     if(data ==1)
                    {
						$("#EmailError").html("Sorry, But this email is used before");
					}
				}
	});
    }));
    $("body").delegate( ".LP", "click", function() {
		var UserID = $(this).attr('data-userid');
		var AccessedPageID = $(this).attr('data-accessedpageid');
		$.ajax({
				type : 'POST',
				url  : 'LikePageProc.php',
				data : {'UserID' : UserID , 'AccessedPageID' : AccessedPageID },
				success: function(data){
					if(data =="error")
                    {
						alert("Sorry , but there's something went wrong !!");
					}
				}
				
			});
			$(this).fadeOut(200,function(){
				$(this).val("Liked")
				$(this).removeClass( "LP" ).addClass( "btn btn-md ULP" );
                $(this).css("background-color","#5b92e3")
				$(this).fadeIn(200);
			});
	});
    $("body").delegate( ".ULP", "click", function() {
		var UserID = $(this).attr('data-userid');
		var AccessedPageID = $(this).attr('data-accessedpageid');
		$.ajax({
				type : 'POST',
				url  : 'UnLikePageProc.php',
				data : {'UserID' : UserID , 'AccessedPageID' : AccessedPageID },
				success: function(data){
					if(data =="error")
                    {
						alert("Sorry , but there's something went wrong !!");
					}
				}
				
			});
			$(this).fadeOut(200,function(){
				$(this).val("Like")
				$(this).removeClass( "ULP" ).addClass( "btn btn-md LP" );
                $(this).css("background-color","#7CCC81")
				$(this).fadeIn(200);
			});
	});
    $("#ManageAdminstration").on("click",function(){
        var AccessedPageID = $(this).attr('data-accessedpageid');
        var UserID = $(this).attr('data-userid');
        $.ajax({
				type : 'GET',
				url  : 'LoadAdminsProc.php',
				data : {'AccessedPageID' : AccessedPageID,'UserID' : UserID},
				success: function(data)
                {
				    	var arr = jQuery.parseJSON(data);
                        var Admins = "" ;
					$.each(arr, function () {
						Admins += getAdminTemplate(this[0],this[1],this[2],this[3],AccessedPageID);
					});
                    $('#AdminsModalBody').html(Admins);
				}
	});
    });
    $("body").delegate("#AddAdmintxt","input",function(){
       var AccessedPageID = $(this).attr('data-pageid');
        var UserID = $(this).attr('data-userid');
        var target = "user";    
        var text = $(this).val();
        $.ajax({
				type : 'GET',
				url  : 'Search.php',
				data : {'Text' : text , 'Stype' : target },
				success: function(data){
					var arr = jQuery.parseJSON(data);
					var Result = "" ;
                    if(text == "")
                    {
                        Result="";
                    }
                    else
                    {
				        $.each(arr, function ()
                        {
                            if(this[0] != UserID )
                                {
						          Result += getSearchAdminTemplate(this[0],this[1],this[2],this[3],AccessedPageID);
                                }
					   });
                    }
					if (Result == "" )
					{
						Result = "No Results Found";
					}
                    $("#adminResult").html(Result);
                }
        });
    });
    $("body").delegate(".AddAdmin","click",function(){
        var AccessedPageID = $(this).attr('data-pageid');
        var UserID = $(this).attr('data-userid');
        $.ajax({
				type : 'POST',
				url  : 'AddAdminProc.php',
				data : {"AccessedPageID" : AccessedPageID , "UserID" :UserID },
				success: function(data){
                    if (data != "error" )
                        {
                            var arr = jQuery.parseJSON(data);
                            var Admins = $("#AdminsModalBody").html();
                            Admins += getAdminTemplate(arr[0],arr[1],arr[2],arr[5],AccessedPageID);
                            $("#AdminsModalBody").html("");
                            $("#AdminsModalBody").html(Admins);
                            $('#AddAdmintxt').val("");
                        }
                }
        });
    });
    $("body").delegate(".RemoveAdmin","click",function(){
        var AccessedPageID = $(this).attr('data-pageid');
        var UserID = $(this).attr('data-userid');
        $.ajax({
				type : 'POST',
				url  : 'DeleteAdminProc.php',
				data : {"AccessedPageID" : AccessedPageID , "UserID" :UserID },
				success: function(data){
                }
        });
        $(this).parent().slideUp(200);
    });
    $("body").delegate('.SJR',"click",function(){
        var UserID = $(this).attr('data-userid');
		var GroupID = $(this).attr('data-groupid');
        $.ajax({
				type : 'POST',
				url  : 'SendJoiningRequestProc.php',
				data : {'UserID' : UserID , 'GroupID' : GroupID },
				success: function(data){
                    if(data =="error")
                    {
						alert("Sorry , but there's something went wrong !!");
					}
				}
			});
        $(this).fadeOut(200,function(){
				$(this).val("Cancel joining request")
                $(this).css('background-color', '#1CCC18');
				$(this).removeClass( "SJR" ).addClass( "btn btn-md CJR" );
				$(this).fadeIn(200);
            });
    });
    $("body").delegate('.CJR',"click",function(){
        var UserID = $(this).attr('data-userid');
		var GroupID = $(this).attr('data-groupid');
        $.ajax({
				type : 'POST',
				url  : 'CancelJoiningRequestProc.php',
				data : {'UserID' : UserID , 'GroupID' : GroupID },
				success: function(data){
					if(data =="error")
                    {
						alert("Sorry , but there's something went wrong !!");
					}
				}
			});
        $(this).fadeOut(200,function(){
				$(this).val("Send joining request")
                $(this).css('background-color', '#7CCC81');
				$(this).removeClass( "CJR" ).addClass( "btn btn-md SJR" );
				$(this).fadeIn(200);
            });
    });
    $("body").delegate('.LG',"click",function(){
        var UserID = $(this).attr('data-userid');
		var GroupID = $(this).attr('data-groupid');
        $.ajax({
				type : 'POST',
				url  : 'LeaveGroup.php',
				data : {'UserID' : UserID , 'GroupID' : GroupID },
				success: function(data){
					if(data =="error")
                    {
						alert("Sorry , but there's something went wrong !!");
					}
				}
			});
                window.location.replace("Library.php");
    });
    $("#ManageAdminstrationG").on("click",function(){
        var GroupID = $(this).attr('data-groupid');
        var UserID = $(this).attr('data-userid');
        $.ajax({
				type : 'GET',
				url  : 'LoadGroupAdminsProc.php',
				data : {'GroupID' : GroupID,'UserID' : UserID},
				success: function(data)
                {
				    	var arr = jQuery.parseJSON(data);
                        var Admins = "" ;
					$.each(arr, function () {
						Admins += getGroupAdminTemplate(this[0],this[1],this[2],this[3],GroupID);
					});
                    $('#GroupAdminsModalBody').html(Admins);
				}
	});
    });
    $("body").delegate("#AddAdminGtxt","input",function(){
       var GroupID = $(this).attr('data-groupid');
        var UserID = $(this).attr('data-userid');
        var target = "user";    
        var text = $(this).val();
        $.ajax({
				type : 'GET',
				url  : 'Search.php',
				data : {'Text' : text , 'Stype' : target },
				success: function(data){
					var arr = jQuery.parseJSON(data);
					var Result = "" ;
                    if(text == "")
                    {
                        Result="";
                    }
                    else
                    {
				        $.each(arr, function ()
                        {
                            if(this[0] != UserID )
                                {
						          Result += getSearchGroupAdminTemplate(this[0],this[1],this[2],this[3],GroupID);
                                }
					   });
                    }
					if (Result == "" )
					{
						Result = "No Results Found";
					}
                    $("#adminResult").html(Result);
                }
        });
    });
    $("body").delegate(".AddGroupAdmin","click",function(){
        var GroupID = $(this).attr('data-groupid');
        var UserID = $(this).attr('data-userid');
        $.ajax({
				type : 'POST',
				url  : 'AddGroupAdminProc.php',
				data : {"GroupID" : GroupID , "UserID" :UserID },
				success: function(data){
                    if (data != "error" )
                        {
                            var arr = jQuery.parseJSON(data);
                            var Admins = $("#GroupAdminsModalBody").html();
                            Admins += getGroupAdminTemplate(arr[0],arr[1],arr[2],arr[5],GroupID);
                            $("#GroupAdminsModalBody").html("");
                            $("#GroupAdminsModalBody").html(Admins);
                            $('#AddAdminGtxt').val("");
                        }
                }
        });
    });
    $("body").delegate(".RemoveGroupAdmin","click",function(){
        var GroupID = $(this).attr('data-groupid');
        var UserID = $(this).attr('data-userid');
        $.ajax({
				type : 'POST',
				url  : 'DeleteGroupAdminProc.php',
				data : {"GroupID" : GroupID , "UserID" :UserID },
				success: function(data){
                }
        });
        $(this).parent().slideUp(200);
    });
    $("#GroupMembers").on("click",function(){
        var GroupID = $(this).attr('data-groupid');
        var UserID = $(this).attr('data-userid');
        $.ajax({
				type : 'GET',
				url  : 'LoadGroupMembersProc.php',
				data : {'GroupID' : GroupID,'UserID' : UserID},
				success: function(data)
                {
				    	var arr = jQuery.parseJSON(data);
                        var Members = "" ;
					$.each(arr, function () {
						Members += getGroupMemberTemplate(this[0],this[1],this[2],this[3],GroupID);
					});
                    $('#GroupMembersModalBody').html(Members);
				}
	});
    });
    $("body").delegate("#AddMemberGtxt","input",function(){
       var GroupID = $(this).attr('data-groupid');
        var UserID = $(this).attr('data-userid');
        var target = "user";    
        var text = $(this).val();
        $.ajax({
				type : 'GET',
				url  : 'Search.php',
				data : {'Text' : text , 'Stype' : target },
				success: function(data){
					var arr = jQuery.parseJSON(data);
					var Result = "" ;
                    if(text == "")
                    {
                        Result="";
                    }
                    else
                    {
				        $.each(arr, function ()
                        {
                            if(this[0] != UserID )
                                {
						          Result += getSearchGroupMemberTemplate(this[0],this[1],this[2],this[3],GroupID);
                                }
					   });
                    }
					if (Result == "" )
					{
						Result = "No Results Found";
					}
                    $("#memberResult").html(Result);
                }
        });
    });
    $("body").delegate(".AddGroupMember","click",function(){
        var GroupID = $(this).attr('data-groupid');
        var UserID = $(this).attr('data-userid');
        $.ajax({
				type : 'POST',
				url  : 'AddGroupMemberProc.php',
				data : {"GroupID" : GroupID , "UserID" :UserID },
				success: function(data){
                    if (data != "error" )
                        {
                            var arr = jQuery.parseJSON(data);
                            var Admins = $("#GroupMembersModalBody").html();
                            Admins += getGroupMemberTemplate(arr[0],arr[1],arr[2],arr[5],GroupID);
                            $("#GroupMembersModalBody").html("");
                            $("#GroupMembersModalBody").html(Admins);
                            $('#AddMemberGtxt').val("");
                        }
                }
        });
    });
    $("body").delegate(".RemoveGroupMember","click",function(){
        var GroupID = $(this).attr('data-groupid');
        var UserID = $(this).attr('data-userid');
        $.ajax({
				type : 'POST',
				url  : 'DeleteGroupMemberProc.php',
				data : {"GroupID" : GroupID , "UserID" :UserID },
				success: function(data){
                }
        });
        $(this).parent().slideUp(200);
    });
    $("body").delegate("#PendingRequests","click",function(){
        var UserID = $(this).attr('data-userid');
        var GroupID = $(this).attr('data-groupid');
		$.ajax({
				type : 'GET',
				url  : 'LoadJoiningRequests.php',
				data : {'UserID' : UserID , 'GroupID' : GroupID},
				success: function(data)
                {
				    	var arr = jQuery.parseJSON(data);
                        var Requests = "" ;
					$.each(arr, function () {
						Requests += getJoiningRequestTemplate(this[0],this[1],this[2],this[3],GroupID);
					});
					if (Requests == "" )
					{
						Requests = "No Requests Found";
					}
                    $('#PendingRequestsResult').html(Requests);
				}
	});
    });
    $("body").delegate(".AJR","click",function(){
        var RequestID = $(this).attr('data-requestid');
        var GroupID = $(this).attr('data-groupid')
        var Reply = 'Approve';
        $.ajax({
				type : 'POST',
				url  : 'ReplyJoiningRequestproc.php',
				data : {'RequestID' : RequestID , 'Reply' : Reply },
				success: function(data){
                     var arr = jQuery.parseJSON(data);
                            var Admins = $("#GroupMembersModalBody").html();
                            Admins += getGroupMemberTemplate(arr[0],arr[1],arr[2],arr[5],GroupID);
                            $("#GroupMembersModalBody").html("");
                            $("#GroupMembersModalBody").html(Admins);
				}
	}); 
        $(this).parent().parent().parent().slideUp(500);
            });
    $("body").delegate(".HJR","click",function(){
        var RequestID = $(this).attr('data-requestid');
        var Reply = 'Hide';
        $.ajax({
				type : 'POST',
				url  : 'ReplyJoiningRequestproc.php',
				data : {'RequestID' : RequestID , 'Reply' : Reply },
				success: function(data){
                     if(data =="error")
                    {
						alert("Sorry , but there's something went wrong !!");
					}   
				}
	           });
        $(this).parent().parent().parent().slideUp(500);
            });
</script>