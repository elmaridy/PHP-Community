<?php
session_start();
if (isset($_SESSION["UserID"]))
{
    include('db_info.php');
    $user = $_SESSION["UserID"];
    function GetUserPagePosts($userid)
    {
        $con = mysqli_connect(HOST,UN,PW,DB);
        $sql = "select post_id , post_text , post_image , poster_id , poster_name , poster_image , 
                (SELECT EXISTS( SELECT * FROM post_likes as l WHERE l.liker_id = $userid AND l.post_id = p.post_id)),
                (select count(*) from post_likes where post_likes.post_id = p.post_id ),poster_type,p.scoop_id,scoop_name,scoop_type
                from post p
                left outer join posters as po using (poster_id)
                JOIN scoop using (scoop_id)
                where poster_id = $userid OR (poster_id IN (SELECT friend_id FROM user_friends WHERE user_id = $userid) AND (scoop_id =1 OR scoop_id = 2)) OR poster_id IN (SELECT page_id FROM user_pages WHERE user_id = $userid) OR scoop_id IN (SELECT group_id from user_group WHERE user_id = $userid) order by post_time desc";
        $posts = mysqli_query($con,$sql);
        while ($r = mysqli_fetch_array($posts))
        {
            echo 
            "<br/>
            <center>
            <div style='width:75%;'>
            <div style='float:left'>
            <img src='$r[5]' alt='PosterImage' width='50px' height = '50px'/>";
            if($r[11] == 0)
            {
                if($r[8] == 0)
                {
                    echo "<label><a href='UserWall.php?accesseduser=$r[3]'>$r[4]</a></label>";
                }
                else if ($r[8] == 1)
                {
                    echo "<label><a href='PageShow.php?accessedpage=$r[3]'>$r[4]</a></label>";
                }
            }
            else if ($r[11] == 1)
            {
                echo "<label><a href='UserWall.php?accesseduser=$r[3]'>$r[4]</a></label> &rarr; <label><a href='GroupShow.php?groupid=$r[9]'>$r[10]</a></label>";
            }
            else
            {
                echo "<label><a href='UserWall.php?accesseduser=$r[3]'>$r[4]</a></label> &rarr; <label><a href='BlogShow.php?blogid=$r[9]'>$r[10]</a></label>";
            }
            echo
            "</div><div style='clear:both;'></div><br/>
            <div style='border:2px solid #7CCC81;border-radius:10px' >
            <br/>
            <p>$r[1]</p>";
            if (!empty($r[2])){ echo "<img src='$r[2]' alt='PostImage' width='50%'/>"; }
            if ($r[7] != 0)
            {
                echo "<br/><p id = 'nolp$r[0]' class='badge' style='background-color:#5b92e3'><span id = 'nol$r[0]'>$r[7]</span> people Liked That .</p>";
            }
            else
            {
                echo "<br/><p id = 'nolp$r[0]' class='badge' style='display:none;background-color:#5b92e3'><span id = 'nol$r[0]'>$r[7]</span> people Liked That .</p>";
            }
            if ($r[6] != 1)
            {
                echo "<br/><input type = 'button' value = 'Like'  class = 'btn btn-md unliked' data-userid = '$userid' data-postid = '$r[0]'  />";
            }
            else
            {
                echo "<br/><input type = 'button' value = 'Liked'   class = 'btn btn-md liked'  data-userid = '$userid' data-postid = '$r[0]' />";
            }
            echo
            "<button type='button' class='btn btn-md showcommentmodal' data-toggle='modal' data-target='#CommentModal' data-userid = '$userid' data-postid = '$r[0]' >Comment</button>
            <br/>
            </div>
            </div>
            </center>
            <br/>
            <br/>
            <br/>
            <br/>
            ";
        }
        mysqli_close($con);
    }
    function GetUserWallPosts($accesseduserid , $userid)
    {
        $con = mysqli_connect("localhost","root","","community");
        $sql = "select * from user where user_id = $accesseduserid";
        $accesseduser = mysqli_query($con,$sql);
        if ($r = mysqli_fetch_array($accesseduser))
        {
            echo
            "<center>
                <img src = 'images/posters/$r[5]' alt='userimage' />
                <h1>$r[1] $r[2]</h1>
            </center>
            ";
        }
        $sql = "select post_id , post_text , post_image , poster_id , poster_name , poster_image , 
                (SELECT EXISTS( SELECT * FROM post_likes as l WHERE l.liker_id = $userid AND l.post_id = p.post_id)),
                (select count(*) from post_likes where post_likes.post_id = p.post_id )
                from post p
                left outer join posters as po using (poster_id)
                where poster_id = $accesseduserid
                order by post_time desc";
        $posts = mysqli_query($con,$sql);
        while ($r = mysqli_fetch_array($posts))
        {
            echo 
            "<center>
            <div>
            <img style='align:left' src='images/posters/$r[5]' alt='PosterImage' width='50px' height = '50px'/>
            <label>$r[4]</label><br/>
            <div style='border:2px solid;width:50%' >
            <p>$r[1]</p>";
            if (!empty($r[2])){ echo "<img src='images/posts/$r[2]' alt='PostImage' width='50%'/>"; }
            if ($r[7] != 0)
            {
                echo "<br/><p id = 'nolp$r[0]'><span id = 'nol$r[0]'>$r[7]</span> people Liked That .</p>";
            }
            else
            {
                echo "<br/><p id = 'nolp$r[0]' style='display:none;'><span id = 'nol$r[0]'>$r[7]</span> people Liked That .</p>";
            }
            if ($r[6] != 1)
            {
                echo "<br/><input type = 'button' value = 'Like'  class = 'unliked' data-userid = '$userid' data-postid = '$r[0]'  />";
            }
            else
            {
                echo "<br/><input type = 'button' value = 'Liked'   class = 'liked'  data-userid = '$userid' data-postid = '$r[0]' />";
            }
            echo
            "</div>
            </div>
            </center>
            ";
        }
        mysqli_close($con);
    }
    function PostWI ($posterid,$scoopid,$text)
    {
        $con = mysqli_connect("localhost","root","","community");
        $d=date('Y-m-d H:i:s');
        $sql = "insert into post(poster_id,scoop_id,post_text,post_time) values($posterid,$scoopid,'$text','$d')";
        $r = mysqli_query($con,$sql);
        mysqli_close($con);
    }
    function Post($posterid,$scoopid,$text,$image)
    {
        $con = mysqli_connect(HOST,UN,PW,DB);
        $sql = "insert into post(poster_id,scoop_id,post_text) values($posterid,$scoopid,'$text')";
        $r = mysqli_query($con,$sql);
        $sql = "SELECT LAST_INSERT_ID();";
        $r = mysqli_query($con,$sql);
        if($p = mysqli_fetch_array($r))
        { $last_id = $p[0];}
        $target_dir = "images/posts/";
        $imageFileType = pathinfo($image["name"],PATHINFO_EXTENSION);
        $target_file = $target_dir .$last_id.".".$imageFileType;
        $uploadOk = 1;
        // Check if image file is a actual image or fake image
        if(isset($_POST["submit"])) {
            $check = getimagesize($image["tmp_name"]);
            if($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
            } else {
                echo "File is not an image.";
                $uploadOk = 0;
            }
        }
        // Check if file already exists
        if (file_exists($target_file)) {
            echo "Sorry, file already exists.";
            $uploadOk = 0;
        }
        // Check file size
        if ($image["size"] > 500000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }
        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
            echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
            $uploadOk = 0;
        }
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
        // if everything is ok, try to upload file
        } else {
            if (!move_uploaded_file($image["tmp_name"], $target_file)) {echo "Sorry, there was an error uploading your file.";}
        }
        $postimage = "images/posts/".$last_id.".".$imageFileType;
        $sql = "update post set post_image = '$postimage' where post_id = $last_id";
        $r = mysqli_query($con,$sql);
        mysqli_close($con);
        header("Location : Library.php");
    }
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <link rel="stylesheet" type="text/css" href="Community.css">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
        <script src="bootstrap-3.3.7/bootstrap-3.3.7/dist/js/bootstrap.min.js"></script>
    </head>
    <body style='background-color:#7CCC81'>
    <center>
    <div style='width:75%;background-color:white'>
    <?php include("LogedHeader.php"); ?>
    <form action="Post.php" method="post" enctype="multipart/form-data">
        <select class="form-control" style="width:20%" name="Scoop">
            <option value="1">Public</option>
            <option value="2">For Friends</option>
        </select>
        <br/>
        <textarea id="PostText" rows="4" cols="50" style="resize: none;" placeholder="Write something" name="PostText"></textarea><br/>
        <input type="file" class="form-control" style="width:30%" name="Image" id="fileToUpload">
        <br/>
        <input id="PostBtn" type="submit" class="btn btn-md" value="Post">
    </form>
    <center>
    <?php GetUserPagePosts($user); ?>
    </div>
    </center>
    <?php include("LogedFooter.php"); ?>
    <?php include("AjaxLibrary.php"); ?>
    </body>
    </html>


<?php
}
else
{
    header("location: Registeration.php");
}
?>