<?php
session_start();
if (isset($_SESSION["UserID"]))
{
    $user = $_SESSION["UserID"];
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="Community.css">
</head>
<body style='background-color:#7CCC81'>
<center>
<div style='width:75%;background-color:white'>
<?php include("LogedHeader.php"); ?>
    <form method="post" action="CreateNewPageProc.php" enctype="multipart/form-data">
    <table style="padding:200px">
        <tr>
            <td>
                <input type = "text" class="form-control" placeholder="Enter Page Name" name = "PageName" id = "PageNametxt" style="margin:20px" required onkeyup="this.value=this.value.replace(/[^a-zA-Z0-9]/g, '')" />
            </td>
        </tr>
        <tr>
            <td>
                <textarea id="PageAbout" class="form-control" style="margin:20px" rows="4" cols="50" style="resize: none;" placeholder="Write about the page" name="PageAbout"></textarea>
            </td>
        </tr>
        <tr>
            <td>
                <input type = "file" class="form-control" name = "PageImage" style="margin:20px" />
            </td>
        </tr>
            <td>
               <input type="submit" class="btn btn-md" value="Create" style="background-color:#5b92e3;color:white;margin:25%"> 
            </td>
        </tr>
    </table>
    </form>
<center>
<?php include("LogedFooter.php"); ?>
<?php include("AjaxLibrary.php"); ?>
</body>
</html>
<?php
}
else
{
    header("location: Registeration.php");
}

?>