<?php
	include("db_info.php");
	$user_id = $_GET['UserID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
    $sql = "UPDATE notification set ISRead = 1 WHERE user_id = $user_id";
    $rslt = mysqli_query($con , $sql);
    $sql = "SELECT note_text ,note_link,note_img FROM notification WHERE user_id = $user_id order by note_time desc";
	$rslt = mysqli_query($con , $sql);
	$CommArray = array();
	while($row = mysqli_fetch_array($rslt)) 
	{
            $CommArray[] = $row;
    }
	mysqli_close($con);
	echo json_encode($CommArray);
?>