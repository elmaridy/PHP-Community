<?php
session_start();
if(!empty($_COOKIE['user']) && !empty($_COOKIE['password']) )
{
    include("db_info.php");
    $email = $_COOKIE['user'];
    $password = $_COOKIE['password'];
    echo $email;
    $con = mysqli_connect(HOST,UN,PW,DB);
    $sql = "SELECT user_id FROM user WHERE email = '$email' and password = '$password'";
    $rslt = mysqli_query($con,$sql);
    if($r=mysqli_fetch_array($rslt))
    {
                $user_id = $r[0];
                $_SESSION["UserID"] = $user_id;
                header("location: Library.php");
    }
    else
    {
        setcookie("user", "", time() - 3600);
        setcookie("password", "", time() - 3600);
    }
}
$msg ='';
if(isset($_GET["error"]) && $_GET["error"] == "invalid" )
{
    $msg = "You have entered invalid email or password";
}

?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body style = "background-color:#7CCC81">
    <div style = "background-color:#5b92e3;padding:15px;height:80px;">
    <form action="Login.php" method="get">
        <input type="submit" class="btn btn-md" value="Log In" id = "LoginBtn" style="float:right;background-color:#7CCC81;color:white">
        <div style="float:right;margin-right:20px;margin-left:20px">
            <input type = "password" class="form-control" placeholder="Enter Your Password" name = "Password" id = "Passwordtxt" />
        </div>
        <div style="float:right;margin-right:20px;margin-left:20px">
            <input type="text" class="form-control" placeholder="Enter Your Email" name = "Email" />
        </div>
        <span style="float:right;color:red;margin-top:10px"> <?php echo $msg ?> </span>
        <div style="clear:both"></div>
        <div class="checkbox" style="float:right;margin-right:30%">
            <label style="color:white"><input type="checkbox" value="1" name='RememberMe'>Remember Me</label>
        </div>
    </form>
    </div>
    <div style="clear:both"></div>
    <center>
    <form action="NewUser.php" method="post">
    <table style="padding:200px">
        <tr>
            <td>
                <input type = "text" class="form-control" placeholder="Enter First Name" name = "FName" id = "FNametxt" style="margin:20px" required onkeyup="this.value=this.value.replace(/[^a-zA-Z0-9]/g, '')" />
            </td>
            <td>
                <input type = "text" class="form-control" placeholder="Enter Last Name" name = "LName" id = "LNametxt" style="margin:20px" required onkeyup="this.value=this.value.replace(/[^a-zA-Z0-9]/g, '')" />
            </td>
        </tr>
        <tr>
            <td>
                <input type = "email" class="form-control" placeholder="Email" name = "Email" id = "Emailtxt" style="margin:20px" required />
            </td>
            <td>
                <span id="EmailError" style="color:red;margin:20px"></span>
            </td>
        </tr>
        <tr>
            <td>
                <input type = "password" class="form-control" placeholder="Enter Password" name = "Password" id = "Passwordtxt" style="margin:20px" required />
            </td>
        </tr>
        <tr>
            <td>
                <input type = "date" class="form-control" name = "BirthDate" id = "BirthDate" style="margin:20px" required />
            </td>
            <td>
                <select class="form-control" style="margin:20px" name="Gender">
                    <option value="M">Male</option>
                    <option value="F">Female</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>
               <input type="submit" class="btn btn-md" value="Sign Up" id = "SignupBtn" style="background-color:#5b92e3;color:white;margin:25%"> 
            </td>
        </tr>
    </table>
    </form>
    </center>
    <div style = "background-color:#5b92e3;padding:15px;height:75px;bottom:0px;position:fixed;width:100%;height:50px;padding:10px;"></div>
    <?php
        include("AjaxLibrary.php");
    ?>
</body>
</html>