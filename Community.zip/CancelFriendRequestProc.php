<?php
include("db_info.php");
	$user_id = $_POST['UserID'];
	$accesseduser_id = $_POST['AccessedUserID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
	$sql = "DELETE FROM friend_request WHERE sender_id= $user_id AND reciver_id = $accesseduser_id AND  is_valid = true";
	$rslt = mysqli_query($con , $sql);
    mysqli_close($con);
    if ($rslt == 1)
	{
		die( "done");
	}
	else
	{
		die( "error");
	}
?>