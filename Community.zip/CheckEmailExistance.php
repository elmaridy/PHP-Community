<?php
include("db_info.php");
$email = $_GET["Email"];
$con = mysqli_connect(HOST,UN,PW,DB);
$sql = "SELECT EXISTS (SELECT email FROM user WHERE email = '$email')";
$rslt = mysqli_query($con,$sql);
if($r = mysqli_fetch_array($rslt))
{
    echo $r[0];
}
?>