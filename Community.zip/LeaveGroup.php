<?php
include("db_info.php");
$userid = $_POST["UserID"];
$groupid = $_POST["GroupID"];
$con = mysqli_connect(HOST,UN,PW,DB);
$sql = "DELETE FROM user_group WHERE user_id =  $userid AND group_id = $groupid ";
$rslt = mysqli_query($con,$sql);
mysqli_close($con);
if ($rslt == 1)
{
	die( "done");
}
else
{
    die( "error");
}
?>