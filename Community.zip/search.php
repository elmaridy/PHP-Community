<?php
	include("db_info.php");
	$text = $_GET['Text'];
    $stype = $_GET['Stype'];
	$con = mysqli_connect(HOST,UN,PW,DB);
    if($stype == "user")
    {
        $sql = "SELECT user_id,first_name,last_name , profile_image_path FROM user WHERE first_name LIKE '%".$text."%' OR last_name LIKE '%".$text."%'";    
    }
    else if ($stype == "page")
    {
        $sql = "SELECT page_id,page_name,page_image FROM page WHERE page_name LIKE '%".$text."%'";
    }
    else if ($stype == "group")
    {
        $sql = "SELECT group_id,group_name,group_image_path FROM `group` WHERE group_name LIKE '%".$text."%'";
    }
    else if ($stype == "blog")
    {
        $sql = "SELECT blog_id,blog_name,blog_img FROM blog WHERE blog_name LIKE '%".$text."%'";
    }
    $rslt = mysqli_query($con , $sql);
	$ResultArray = array();
	while($row = mysqli_fetch_array($rslt)) 
	{
            $ResultArray[] = $row;
    }
	mysqli_close($con);
	echo json_encode($ResultArray);
?>