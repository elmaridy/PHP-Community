<?php
session_start();
if (isset($_SESSION["UserID"]))
{
    $user = $_SESSION["UserID"];
include('db_info.php');
function ShowPost($userid,$postid)
{
	$con = mysqli_connect(HOST,UN,PW,DB);
	$sql = "select post_id , post_text , post_image , poster_id , poster_name , poster_image , 
            (SELECT EXISTS( SELECT * FROM post_likes as l WHERE l.liker_id = $userid AND l.post_id = p.post_id)),
			(select count(*) from post_likes where post_likes.post_id = p.post_id ),
			poster_type,scoop_id,scoop_type
			from post p
			left outer join posters as po using (poster_id) JOIN scoop using(scoop_id)
			where post_id = $postid";
	$post = mysqli_query($con,$sql);
	$sql = "SELECT post_id ,commenter_id,comm_text,comm_img, p.poster_id , p.poster_name ,p.poster_image FROM post_comments left outer join posters as p on commenter_id = p.poster_id WHERE post_id = $postid";
	$comments = mysqli_query($con,$sql);
	if ($r = mysqli_fetch_array($post))
	{
		if($r[8] == 0 && $r[9] != 1)
		{
			if($r[9] == 2)
			{
				$sql = 'SELECT EXISTS( SELECT * FROM user_friends WHERE user_id = $userid AND friend_id = $r[3])';
				$rslt = mysqli_query($con,$sql);
				if($f = mysqli_fetch_array($rslt))
				{
					if($f[0] == 0)
					{
						mysqli_close($con);
						return false ;
					}
				}
			}
		}
        else if ($r[10] == 1)
        {
            $sql = 'SELECT EXISTS( SELECT * FROM user_group WHERE user_id = $userid AND group_id = $r[9])';
				$rslt = mysqli_query($con,$sql);
				if($f = mysqli_fetch_array($rslt))
				{
					if($f[0] == 0)
					{
						mysqli_close($con);
						return false ;
					}
				}
        }
		echo
		"<hr/><center>
		<div>
		<img style='align:left' src='$r[5]' alt='PosterImage' width='50px' height = '50px'/>
		<label><a href='testwall.php?accessedUserId=$r[3]'>$r[4]</a></label><br/>
		<div style='border:2px solid #7CCC81;border-radius:10px;width:75%' >
		<p>$r[1]</p>";
		if (!empty($r[2])){ echo "<img src='$r[2]' alt='PostImage' width='50%'/>"; }
		if ($r[7] != 0)
		{
			echo "<br/><p id = 'nolp$r[0]'><span id = 'nol$r[0]'>$r[7]</span> people Liked That .</p>";
		}
		else
		{
			echo "<br/><p id = 'nolp$r[0]' style='display:none;'><span id = 'nol$r[0]'>$r[7]</span> people Liked That .</p>";
		}
		if ($r[6] != 1)
		{
			echo "<br/><input type = 'button' value = 'Like'  class = 'btn btn-md unliked' data-userid = '$userid' data-postid = '$r[0]'  />";
		}
		else
		{
			echo "<br/><input type = 'button' value = 'Liked'   class = 'btn btn-md liked'  data-userid = '$userid' data-postid = '$r[0]' />";
		}
		echo
		"</div>
		</div>
		</center><hr/>
		";
		while ($r = mysqli_fetch_array($comments))
		{
			echo
			"<hr/><center><div><hr/><img src ='$r[6]' alt = 'CommenterID' width='30px' height = '30px' />
			<label>$r[5]</label><br/><br/><p>$r[2]</p>";
			if(!empty($r[3]))
			{
				echo "<img src='$r[3]' alt = 'CommentImage' />";
			}
			echo "<hr/></div></center><hr/>";
		}
        echo "<br/><br/><br/>";
	}
	mysqli_close($con);
	return true;
}
if (isset($_GET['postid']))
{
	$postid = $_GET['postid'];
}
else
{
	header('location : Library.php');
}
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="Community.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
<?php include("LogedHeader.php"); ?>
<?php if(ShowPost(1,$postid) !=true) {header('location : Library.php');}?>
<form action='PostCommentWI.php' method="post" enctype="multipart/form-data">
    <center><div style='width:50%'><input type="file" name="Image" id="fileToUpload"><br/>
    <input type = 'text' class = 'form-control' id = 'CommentText' name='CommentText' value='' />
	<input type="hidden" name="PostID" value="<?php echo $postid?>">
	<center> <input type="submit" value="Comment" class="btn" style="background-color:#7CCC81;color:white;" id = 'SendComment' /></center></div></center>
</form>
    <?php include("LogedFooter.php"); ?>
    <?php include("AjaxLibrary.php"); ?>
</body>
</html>
<?php
}
else
{
    header("location: Registeration.php");
}
?>