<?php
session_start();
include('db_info.php');
$user = $_SESSION["UserID"];
if(!empty($_POST['ScoopID']) && !empty($_FILES['ScoopImage']['name']))
{
    $scoopid = $_POST['ScoopID'];
    $image = $_FILES['ScoopImage'];
    $con = mysqli_connect(HOST,UN,PW,DB);
    $d = date("Y-M-D-h-m-s");
        $target_dir = "images/Scoop/";
        $imageFileType = pathinfo($image["name"],PATHINFO_EXTENSION);
        $target_file = $target_dir.$scoopid.$d.".".$imageFileType;
        $uploadOk = 1;
        // Check if image file is a actual image or fake image
        if(isset($_POST["submit"])) {
            $check = getimagesize($image["tmp_name"]);
            if($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
            } else {
                echo "File is not an image.";
                $uploadOk = 0;
            }
        }
        // Check file size
        if ($image["size"] > 500000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }
        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
            $uploadOk = 0;
        }
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
        // if everything is ok, try to upload file
        }
    else {
            $sql = "SELECT group_image_path FROM `group` WHERE group_id = $scoopid";
            $rslt = mysqli_query($con,$sql);
            if ($r = mysqli_fetch_array($rslt))
            {
                $lastpimg = $r[0];
            }
            if (!move_uploaded_file($image["tmp_name"], $target_file)) 
            {
                echo "Sorry, there was an error uploading your file.";
            }
            else
            {
                if($lastpimg != "images/posters/defaultG.png" )
                unlink($lastpimg);
                $sql = "UPDATE `group` set group_image_path = '$target_file' WHERE group_id = $scoopid;";
                $r = mysqli_query($con,$sql);
                $sql = "insert into post(poster_id,scoop_id,post_text) values($user,$scoopid,'Has Changed Group Picture')";
                $r = mysqli_query($con,$sql);
                $sql = "SELECT LAST_INSERT_ID();";
                $r = mysqli_query($con,$sql);
                if($p = mysqli_fetch_array($r))
                { $last_id = $p[0];}
                $target_dir = "images/posts/";
                $target_file2 = $target_dir.$last_id.".".$imageFileType;
                if (!copy($target_file, $target_file2)) 
                {
                    echo "Sorry, there was an error uploading your file.";
                }
                $sql = "update post set post_image = '$target_file2' where post_id = $last_id";
                $r = mysqli_query($con,$sql);
        }
        mysqli_close($con);
        header("location: GroupShowAdmin.php?groupid=$scoopid");    
    }
}
else
{
    header('Location: Library.php');
}

?>