<?php
session_start();
if (isset($_SESSION["UserID"]))
{
    include("db_info.php");
    $user = $_SESSION["UserID"];
    $blogid = $_GET["blogid"];
    function GetBlogPosts($blogid , $userid)
    {
        $con = mysqli_connect(HOST,UN,PW,DB);
                $sql = "SELECT * FROM blog WHERE blog_id = $blogid";
                $accessedblog = mysqli_query($con,$sql);
                if ($r = mysqli_fetch_array($accessedblog))
                {
                    echo
                    "
                    <center>
                        <img src = '$r[2]' alt='userimage' />
                        <h1>$r[1]</h1>
                    </center>
                    <br/><br/><br/>
                    <center>
                    <div style='border-style: solid;border-radius:5px;border-width:2px;border-color:#7CCC81;width:50%'>
                    $r[3]
                    </div>
                    </center>
                    <form action='Post.php' method='post' enctype='multipart/form-data'>
                    <input type='hidden' name='Scoop' value='$blogid' />
                    <br/>
                    <textarea id='PostText' rows='4' cols='50' style='resize: none;' placeholder='Write something' name='PostText'></textarea><br/>
                    <input type='file' class='form-control' style='width:30%' name='Image' id='fileToUpload'>
                    <br/>
                    <input id='PostBtn' type='submit' class='btn btn-md' value='Post'>
                </form><br/><br/><br/>
                    ";
                }   
                $sql = "select post_id , post_text , post_image , poster_id , poster_name , poster_image , 
                        (SELECT EXISTS( SELECT * FROM post_likes as l WHERE l.liker_id = $userid AND l.post_id = p.post_id)),
                        (select count(*) from post_likes where post_likes.post_id = p.post_id ),poster_type,p.scoop_id,scoop_name,scoop_type
                        from post p
                        left outer join posters as po using (poster_id) JOIN scoop using (scoop_id)
                        where scoop_id = $blogid
                        order by post_time desc";
                $posts = mysqli_query($con,$sql);
                while ($r = mysqli_fetch_array($posts))
                {
                   echo 
                    "<br/>
                    <center>
                    <div style='width:75%;'>
                    <div style='float:left'>
                    <img src='$r[5]' alt='PosterImage' width='50px' height = '50px'/>
                    <label><a href='UserWall.php?accesseduser=$r[3]'>$r[4]</a></label> &rarr; <label><a href='BlogShow.php?blogid=$r[9]'>$r[10]</a></label></div>
                    <div style='clear:both;'></div><br/>
                    <div style='border:2px solid #7CCC81;' >
                    <br/>
                    <p>$r[1]</p>";
                    if (!empty($r[2])){ echo "<img src='$r[2]' alt='PostImage' width='50%'/>"; }
                    if ($r[7] != 0)
                    {
                        echo "<br/><p id = 'nolp$r[0]'><span id = 'nol$r[0]'>$r[7]</span> people Liked That .</p>";
                    }
                    else
                    {
                        echo "<br/><p id = 'nolp$r[0]' style='display:none;'><span id = 'nol$r[0]'>$r[7]</span> people Liked That .</p>";
                    }
                    if ($r[6] != 1)
                    {
                        echo "<br/><input type = 'button' value = 'Like'  class = 'btn btn-md unliked' data-userid = '$userid' data-postid = '$r[0]'  />";
                    }
                    else
                    {
                        echo "<br/><input type = 'button' value = 'Liked'   class = 'btn btn-md liked'  data-userid = '$userid' data-postid = '$r[0]' />";
                    }
                    echo
                    "<button type='button' class='btn btn-md showcommentmodal' data-toggle='modal' data-target='#CommentModal' data-userid = '$userid' data-postid = '$r[0]' >Comment</button>
                    <br/>
                    </div>
                    </div>
                    </center>
                    <br/>
                    <br/>
                    <br/>
                    <br/>
                    ";
                }        
            
        mysqli_close($con);
    }
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="Community.css">
</head>
<body style='background-color:#7CCC81'>
<center>
<div style='width:75%;background-color:white'>
<?php include("LogedHeader.php"); ?>
<center>
<?php GetBlogPosts($blogid , $user); ?>
<?php include("LogedFooter.php"); ?>
<?php include("AjaxLibrary.php"); ?>
</body>
</html>
<?php
}
else
{
    header("location: Registeration.php");
}
?>