<?php
	include("db_info.php");
	$user_id = $_GET['UserID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
    $sql = "SELECT EXISTS( SELECT * FROM friend_request WHERE reciver_id = $user_id and Seen = 0)";
    $rslt = mysqli_query($con , $sql);
    mysqli_close($con);
    if($row = mysqli_fetch_array($rslt))
    {
        echo $row[0];
    }
?>