
<?php
	include("db_info.php");
	$user_id = $_POST['UserID'];
	$group_id = $_POST['GroupID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
	$sql = "DELETE FROM user_group WHERE group_id = $group_id AND user_id = $user_id ";
	$rslt = mysqli_query($con , $sql);
	$sql = 
        "INSERT INTO notification (note_text , note_link , note_img, user_id) SELECT ( SELECT  concat('You had been removed from ',(select group_name from `group` where group_id = $group_id),' group members.')),'GroupShow.php?groupid=$group_id',(SELECT group_image_path from `group` where group_id = $group_id),$user_id" ;
	$rslt = mysqli_query($con , $sql);
	mysqli_close($con);
	if ($rslt == 1)
	{
		die( "done");
	}
	else
	{
		die( "error");
	}
?>