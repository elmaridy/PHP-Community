<?php
include('db_info.php');
if(!empty($_POST['UserID']) && !empty($_FILES['ProfileImage']['name']))
{
    $userid = $_POST['UserID'];
    $image = $_FILES['ProfileImage'];
    $con = mysqli_connect(HOST,UN,PW,DB);
    $d = date("Y-M-D-h-m-s");
        $target_dir = "images/posters/";
        $imageFileType = pathinfo($image["name"],PATHINFO_EXTENSION);
        $target_file = $target_dir.$userid.$d.".".$imageFileType;
        $uploadOk = 1;
        // Check if image file is a actual image or fake image
        if(isset($_POST["submit"])) {
            $check = getimagesize($image["tmp_name"]);
            if($check !== false) {
                echo "File is an image - " . $check["mime"] . ".";
                $uploadOk = 1;
            } else {
                echo "File is not an image.";
                $uploadOk = 0;
            }
        }
        // Check file size
        if ($image["size"] > 500000) {
            echo "Sorry, your file is too large.";
            $uploadOk = 0;
        }
        // Allow certain file formats
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        && $imageFileType != "gif" ) {
            $uploadOk = 0;
        }
        // Check if $uploadOk is set to 0 by an error
        if ($uploadOk == 0) {
            echo "Sorry, your file was not uploaded.";
        // if everything is ok, try to upload file
        }
    else {
            $sql = "SELECT poster_image FROM posters WHERE poster_id = $userid";
            $rslt = mysqli_query($con,$sql);
            if ($r = mysqli_fetch_array($rslt))
            {
                $lastpimg = $r[0];
            }
            if (!move_uploaded_file($image["tmp_name"], $target_file)) 
            {
                echo "Sorry, there was an error uploading your file.";
            }
            else
            {
                if($lastpimg != "images/posters/defaultF.jpg" && $lastpimg !="images/posters/defaultM.jpg" && $lastpimg != "images/posters/defaultP.jpg" )
                unlink($lastpimg);
                $sql = "UPDATE posters set poster_image = '$target_file' WHERE poster_id = $userid;";
                $r = mysqli_query($con,$sql);
                if (isset($_POST["Page"]))
                {
                    $sql = "UPDATE page SET page_image = '$target_file' WHERE page_id = $userid;";
                    $r = mysqli_query($con,$sql);
                }
                else
                {
                    $sql = "UPDATE user SET profile_image_path = '$target_file' WHERE user_id = $userid;";
                    $r = mysqli_query($con,$sql);
                }
                $sql = "insert into post(poster_id,scoop_id,post_text) values($userid,1,'Has Changed Profile Picture')";
                $r = mysqli_query($con,$sql);
                $sql = "SELECT LAST_INSERT_ID();";
                $r = mysqli_query($con,$sql);
                if($p = mysqli_fetch_array($r))
                { $last_id = $p[0];}
                $target_dir = "images/posts/";
                $target_file2 = $target_dir.$last_id.".".$imageFileType;
                if (!copy($target_file, $target_file2)) 
                {
                    echo "Sorry, there was an error uploading your file.";
                }
                $sql = "update post set post_image = '$target_file2' where post_id = $last_id";
                $r = mysqli_query($con,$sql);
        }
        mysqli_close($con);
        if(isset($_POST["Page"]))
        {
            header("location: PageShowAdmin.php?accessedpage=$userid");    
        }
        else
        {
            header('Location: Library.php');
        }
}
}
else
{
    header('Location: Library.php');
}

?>