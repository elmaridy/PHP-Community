<?php
include("db_info.php");
$userid = $_POST["UserID"];
$pageid = $_POST["AccessedPageID"];
$con = mysqli_connect(HOST,UN,PW,DB);
$sql = "INSERT INTO user_pages (user_id , page_id) values ( $userid , $pageid )";
$rslt = mysqli_query($con,$sql);
mysqli_close($con);
if ($rslt == 1)
{
	die( "done");
}
else
{
    die( "error");
}
?>