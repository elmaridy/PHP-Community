<?php
include("db_info.php");
	$user_id = $_POST['UserID'];
	$accesseduser_id = $_POST['AccessedUserID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
	$sql = " INSERT INTO friend_request (sender_id,reciver_id,is_valid,is_approved) values ($user_id, $accesseduser_id,true,false)";
	$rslt = mysqli_query($con , $sql);
    mysqli_close($con);
    if ($rslt == 1)
	{
		die( "done");
	}
	else
	{
		die( "error");
	}
?>