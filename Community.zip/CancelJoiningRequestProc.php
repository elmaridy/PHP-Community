<?php
include("db_info.php");
	$user_id = $_POST['UserID'];
	$group_id = $_POST['GroupID'];
	$con = mysqli_connect(HOST,UN,PW,DB);
	$sql = "DELETE FROM joining_request WHERE sender_id= $user_id AND group_id = $group_id AND  is_valid = true";
	$rslt = mysqli_query($con , $sql);
    mysqli_close($con);
    if ($rslt == 1)
	{
		die( "done");
	}
	else
	{
		die( "error");
	}
?>